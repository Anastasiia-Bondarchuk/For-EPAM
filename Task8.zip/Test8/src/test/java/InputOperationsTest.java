import static org.junit.Assert.*;

public class InputOperationsTest {

    @org.junit.Test
    public void theMostOften() {
        String path = "C:\\Users\\Настя\\Desktop\\BatsJava.txt";
        InputOperations Word = new InputOperations(path);
        Word.TheMostOften();
        assertEquals("bats", Word.getWord1());
    }

    @org.junit.Test
    public void theLongestWord() {
        String path = "C:\\Users\\Настя\\Desktop\\BatsJava.txt";
        InputOperations Word = new InputOperations(path);
        Word.TheLongestWord();
        assertEquals("Yinpterochiroptera", Word.getWord1());
    }

    @org.junit.Test
    public void dublicates() {
        String path = "C:\\Users\\Настя\\Desktop\\BatsJava.txt";
        InputOperations Word = new InputOperations(path);
        Word.Dublicates();
        assertEquals("insectivores", Word.getWord1());
    }
}