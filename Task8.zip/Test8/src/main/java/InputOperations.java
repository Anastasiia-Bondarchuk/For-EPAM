import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.io.*;

public class InputOperations {

    private String[] words;
    String Word1 = "";

    public String getWord1() {
        return Word1;
    }

    public String getWord2() {
        return Word2;
    }

    public String getWord3() {
        return Word3;
    }

    String Word2 = "";
    String Word3 = "";

    public InputOperations(String path) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(path));
            String line;
            while ((line = br.readLine()) != null) {
                words = line.split(" ");
            }
        } catch (Exception ex) {
            return;
        }

        for (int i = 0; i < words.length; i++) {
            words[i] = words[i].replace(".", "");
            words[i] = words[i].replace(",", "");
            words[i] = words[i].replace("(", "");
            words[i] = words[i].replace(")", "");
            words[i] = words[i].replace(";", "");
            words[i] = words[i].replace(":", "");
            words[i] = words[i].replace("-", "");
        }
    }

    public void TheMostOften() {
        HashMap<String, Integer> hs = new HashMap<String, Integer>();
        for (int i = 0; i < words.length; i++) {
            if (hs.containsKey(words[i])) {
                hs.put(words[i], hs.get(words[i]) + 1);
            } else hs.put(words[i], 1);
        }
        Set<Map.Entry<String, Integer>> set = hs.entrySet();

        int value = 0;

        for (Map.Entry<String, Integer> me : set) {
            if (me.getValue() > value) {
                value = me.getValue();
                Word1 = me.getKey();
            }
        }
        System.out.print("First word: " + Word1 + " is " + value + " times\n");
        hs.remove(Word1);
        value = 0;
        for (Map.Entry<String, Integer> me : set) {
            if (me.getValue() > value) {
                value = me.getValue();
                Word2 = me.getKey();
            }
        }
        System.out.print("Second word: " + Word2 + " is " + value + " times\n");
        hs.remove(Word2);
        value = 0;
        for (Map.Entry<String, Integer> me : set) {
            if (me.getValue() > value) {
                value = me.getValue();
                Word3 = me.getKey();
            }
        }
        System.out.print("Third word: " + Word3 + " is " + value + " times\n");
        System.out.print("In alphabetical order\n");

        boolean swapped = false;
        do {
            swapped = false;
            if (Word2.compareTo(Word1) < 0) {
                String tmp = Word2;
                Word2 = Word1;
                Word1 = tmp;
                swapped = true;
            }
            if (Word3.compareTo(Word2) < 0) {
                String tmp = Word3;
                Word3 = Word2;
                Word2 = tmp;
                swapped = true;
            }
        } while (swapped);
        System.out.print(Word1 + ", " + Word2 + ", " + Word3);
    }

    public void TheLongestWord() {
        HashMap<String, Integer> hs = new HashMap<String, Integer>();
        for (int i = 0; i < words.length; i++) {
            if (hs.containsKey(words[i])) {
                hs.put(words[i], hs.get(words[i]) + 1);
            } else hs.put(words[i], words[i].length());
        }
        Set<Map.Entry<String, Integer>> set = hs.entrySet();
        int value = 0;

        for (Map.Entry<String, Integer> me : set) {
            if (me.getValue() > value) {
                value = me.getValue();
                Word1 = me.getKey();
            }
        }
        System.out.print(Word1 + " ==> " + value + "\n");
        hs.remove(Word1);
        value = 0;
        for (Map.Entry<String, Integer> me : set) {
            if (me.getValue() > value) {
                value = me.getValue();
                Word2 = me.getKey();
            }
        }
        System.out.print(Word2 + " ==> " + value + "\n");
        hs.remove(Word2);
        value = 0;
        for (Map.Entry<String, Integer> me : set) {
            if (me.getValue() > value) {
                value = me.getValue();
                Word3 = me.getKey();
            }
        }
        System.out.print(Word3 + " ==> " + value + "\n");
    }

    public void Dublicates() {
        Set<String> set = new HashSet<>();
        for (int i = 0; i < words.length; i++) {
            for (int j = 1; j < words.length; j++) {
                if (words[i] == words[j]) {
                    set.add(words[i]);
                    break;
                }
            }
        }
        String[] MyArr = set.toArray(new String[set.size()]);
        Word1 = MyArr[0];
        Word2 = MyArr[1];
        Word3 = MyArr[2];
        System.out.print(Word1 + ", " + Word2 + ", " + Word3);
    }
}
