import java.util.Scanner;

public class Program {

    public static void OutPut(Rectangle[] R)
    {
        for (int i = 0; i < R.length; i++) {
            if (R[i]==null)
            {
                R[i] = new Rectangle(0,0);
            }
            else System.out.print("Rectangle " + i + ": ("+ R[i].getSideA() + ", " + R[i].getSideB()+")\n");
        }
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Input a number: ");
        int n = in.nextInt();
        Rectangle []arrRect = new Rectangle[n+1];
        for (int i = 0; i < n; i++) {
            System.out.print("Input length of side A: \n");
            int A = in.nextInt();
            System.out.print("Input length of side B: \n");
            int B = in.nextInt();
            arrRect[i]= new Rectangle(A,B);
            if(i<n-1)
                System.out.print("Another one\n");
        }
        ArrayRectangle arr = new ArrayRectangle(arrRect);
        OutPut(arrRect);
        System.out.print("After adding new rectangle \n");
        arr.AddRectangle(new Rectangle(5,9));
        OutPut(arrRect);
        System.out.print("\nMax Area:" + arr.numberMaxArea(arrRect));
        System.out.print("\nMin perimeter:" + arr.numberMinPerimeter(arrRect));
        System.out.print("\nNumber of squares:" + arr.numberSquare(arrRect));
    }

}
