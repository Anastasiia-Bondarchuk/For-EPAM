public class Rectangle {
    private double sideA, sideB;

    public Rectangle(double a, double b) {
        sideA = a;
        sideB = b;
    }

    public Rectangle(double a) {
        sideA = a;
        sideB = 5;
    }

    public Rectangle() {
        sideA = 4;
        sideB = 3;
    }

    public double getSideA() {
        return sideA;
    }

    public double getSideB() {
        return sideB;
    }

    public double area() {
        return sideA * sideB;
    }

    public double perimeter() {
        return (sideA + sideB)*2;
    }

    public boolean isSquare() {
        if (sideB == sideB)
            return true;
        else return false;
    }

    public void ReplaceSides() {
        double temp;
        temp = sideA;
        sideA = sideB;
        sideB = temp;
    }
}
