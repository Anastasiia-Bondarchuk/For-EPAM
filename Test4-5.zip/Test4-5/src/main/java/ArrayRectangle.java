public class ArrayRectangle {
    private final Rectangle[] rectangle_array;

    public ArrayRectangle(int n) {
        this.rectangle_array = new Rectangle[n];
    }

    public ArrayRectangle(Rectangle[] arr) {
        this.rectangle_array = arr;
    }
    public ArrayRectangle() {rectangle_array = new Rectangle[]{new Rectangle(7, 8), new Rectangle(8, 9)};
    }

    public boolean AddRectangle(Rectangle n) {
        boolean check = false;
        for (int i = 0; i < rectangle_array.length; i++) {
            if (rectangle_array[i].getSideA() == 0 && rectangle_array[i].getSideB()==0) {
                rectangle_array[i] = n;
                check = true;
            }
            if (check)
                break;
        }
        return check;
    }

    public double numberMaxArea(Rectangle[] arr) {
        double temp = arr[0].area();
        for (int i = 0; i < rectangle_array.length; i++) {
            if (arr[i].area() > temp) {
                temp = arr[i].area();
            }
        }

        return temp;
    }

    public double numberMinPerimeter(Rectangle[] arr) {
        double temp = arr[0].perimeter();
        for (int i = 0; i < rectangle_array.length; i++) {
            if (arr[i].perimeter() < temp) {
                temp = arr[i].perimeter();
            }
        }
        return temp;
    }

    public int numberSquare(Rectangle[] arr) {
        int count=0;
        for (int i = 0; i < rectangle_array.length; i++)
        {
            if (arr[i].getSideA()==arr[i].getSideB())
                count++;
        }
        return count;
    }
}