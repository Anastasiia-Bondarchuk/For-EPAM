import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RectangleTest {

    @Test
    void area() throws Exception{
        Rectangle R = new Rectangle(6,9);
        assertEquals(6*9, R.area());
    }

    @Test
    void perimeter() throws Exception{
        Rectangle R = new Rectangle(6,9);
        assertEquals((6+9)*2, R.perimeter());
    }

    @Test
    void isSquare() throws Exception{
        Rectangle R = new Rectangle(6,6);
        assertTrue(R.isSquare());
    }

    @Test
    void replaceSides() throws Exception{
        Rectangle R = new Rectangle(7,8);
        R.ReplaceSides();
        double expA = R.getSideA();
        double expB = R.getSideB();
        assertEquals(8, expA);
        assertEquals(7, expB);
    }
}