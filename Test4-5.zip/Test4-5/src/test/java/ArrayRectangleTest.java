import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ArrayRectangleTest {

    @Test
    void addRectangle() throws Exception {
        ArrayRectangle rect = new ArrayRectangle();
        assertFalse(rect.AddRectangle(new Rectangle()));
    }

    @Test
    void numberMaxArea() throws Exception{
        Rectangle[] arr = new Rectangle[]{new Rectangle(7, 8), new Rectangle(8, 9)};
        ArrayRectangle rect = new ArrayRectangle();
        double exp = 8 * 9;
        assertEquals(exp, rect.numberMaxArea(arr));
    }

    @Test
    void numberMinPerimeter() throws Exception{
        Rectangle[] arr = new Rectangle[]{new Rectangle(7, 8), new Rectangle(8, 9)};
        ArrayRectangle rect = new ArrayRectangle(arr);
        double exp = (7 + 8)*2;
        assertEquals(exp, rect.numberMinPerimeter(arr));
    }

    @Test
    void numberSquare() throws Exception{
        Rectangle[] arr = new Rectangle[]{new Rectangle(8, 8), new Rectangle(8, 9)};
        ArrayRectangle rect = new ArrayRectangle();
        int exp = 1;
        assertEquals(exp, rect.numberSquare(arr));
    }
}