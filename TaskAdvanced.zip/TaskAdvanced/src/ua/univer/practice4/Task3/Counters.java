package ua.univer.practice4.Task3;

public class Counters extends Thread{

    private int counter;
    private int counter2;

    public Counters() {
        this.counter = 5;
        this.counter2 = 6;
    }

    public void compare()
    {
        counter = 5;
        counter2 = 6;
        System.out.println("Not synchronized:");
        System.out.print(counter+" ");
        System.out.print(counter2);

        if(counter>counter2)
            System.out.println("\nFirst is bigger");
        else if(counter<counter2)
            System.out.println("\nSecond is bigger");
        else System.out.println("\nEquals");

        counter=counter+1;
        System.out.print(counter+" ");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        counter2=counter2+1;
        System.out.print(counter2+"\n\n");
    }
    public synchronized void compareSync()
    {
        counter = 5;
        counter2 = 6;
        System.out.println("Synchronized:");
        System.out.print(counter+" ");
        System.out.print(counter2);

        if(counter>counter2)
            System.out.println("\nFirst is bigger");
        else if(counter<counter2)
            System.out.println("\nSecond is bigger");
        else System.out.println("\nEquals");

        counter=counter+1;
        System.out.print(counter+" ");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        counter2=counter2+1;
        System.out.print(counter2+"\n\n");
    }
    @Override
    public void run() {
        compare();
        compareSync();
    }


    public static void main(String[] args) throws InterruptedException {
        Counters counters1 = new Counters();
        Counters counters2 = new Counters();
        Counters counters3 = new Counters();
        counters1.start();
        counters2.start();
        counters3.start();
    }


}


