package ua.univer.practice3.Task3.FirstPart;

import org.junit.jupiter.api.Test;
import ua.univer.practice3.Task3.FirstPart.PairStringListImpl;

import static org.junit.jupiter.api.Assertions.*;

class PairStringListImplTest {

    @Test
    void size() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        assertEquals(4, my.size());
    }

    @Test
    void add() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        assertEquals(true, my.contains("2"));
    }

    @Test
    void addbyIndex() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.addbyIndex(0,"9");
        assertEquals(true, my.contains("9"));
    }

    @Test
    void deletebyIndex() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        my.deletebyIndex(1);
        assertEquals(false, my.contains("2"));
    }

    @Test
    void getNodeByIndex() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        assertEquals("4",  my.getNodeByIndex(3).element.first);
    }

    @Test
    void deletebyObject() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        my.deletebyObject("3");
        assertEquals(false,  my.contains("3"));
    }

    @Test
    void addCollectionByIndex() {

        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");

        PairStringListImpl second = new PairStringListImpl();
        second.add("wow");
        second.add("aww");
        second.add("cute");
        second.add("qwq");
        second.addCollectionByIndex(3,my);

        assertEquals(true, second.contains("3"));
    }

    @Test
    void addCollection() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");

        PairStringListImpl second = new PairStringListImpl();
        second.add("wow");
        second.add("aww");
        second.add("cute");
        second.add("qwq");
        second.addCollection(my);

        assertEquals(true, second.contains("3"));
    }

    @Test
    void setNodeByIndex() {
        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        my.setNodeByIndex(1, "nya");
        assertEquals(true, my.contains("nya"));
        assertEquals(false, my.contains("2"));
    }
}