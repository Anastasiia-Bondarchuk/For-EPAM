package ua.univer.practice3.Task3.FirstPart;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

public class PairStringListImpl implements Iterable{

    static class Pair
    {
        String first, last;

        public Pair(String _first) {
            first = last=_first;
        }

        @Override
        public String toString() {
            return "" + first + ", " + last + ", ";
        }
    }

    Pair pair;

    static class Node {
        Pair element;
        Node next;

        public Node(Pair element) {
            this.element = element;
        }

        @Override
        public String toString() {
            return "" + element + ' ';
        }
    }
    Node head;

    public int size()
    {
        Node current = head;
        int count=0;
        while(current!=null)
        {
            count=count+1;
            current=current.next;
        }
        return count;
    }

    public void add(String element)
    {
        pair = new Pair(element);
        Node current = new Node(pair);
        current.next=null;
        if(head==null)
        {
            head = current;
        }else{
            Node temp = head;
            while(temp.next!=null)
            {
                temp=temp.next;
            }
            temp.next=current;
        }
    }

    public void addbyIndex(Integer index, String element)
    {
        Objects.checkIndex(index, size()+1);
        pair = new Pair(element);
        Node current = new Node(pair);
        if(index==0)
        {
            current.next=head;
            head = current;
        }else if(index == size()+1){
            Node last = head;
            while(last!=null)
                last=last.next;
            last.next=current;
            last=current;
        }else {
            Node prev = head;
            for(int i=0;i<index-1;i++)
            {
                prev=prev.next;
            }
            current.next=prev.next;
            prev.next=current;
        }
    }

    public void deletebyIndex(int index)
    {
        if(index==0)
        {
            head=head.next;
        }else{
            Node current = head;
            Node temp=null;
            for(int i=0;i<index-1;i++)
            {
                current=current.next;
            }
            temp=current.next;
            current.next=temp.next;
        }
    }

    public Node getNodeByIndex(int index)
    {
        if(index==0)
        {
            return head;
        }else{
            Node current = head;
            Node temp=null;
            for(int i=0;i<index;i++)
            {
                current=current.next;
            }
            return current;
        }
    }

    public void deletebyObject(String string)
    {
        if(string.equals(head.element.first))
        {
            head=head.next;
        }else
        {
            Node current = head;
            Node prev=null;
            while(current.next!=null)
            {
                if(current.next.element.first.equals(string))
                {
                    current.next=current.next.next;
                    break;
                }
                prev=current;
                current=current.next;
            }
        }
    }

    public boolean contains(String value)
    {
        Node current = head;
        while(current!=null)
        {
            if(current.element.first.equals(value))
                return true;
            current = current.next;
        }
        return false;
    }

    public void addCollectionByIndex(int index, PairStringListImpl collection)
    {
        for(int i=collection.size()-1;i>=0;i--)
        {
            addbyIndex(index, collection.getNodeByIndex(i).element.first);
        }
    }

    public void addCollection(PairStringListImpl collection)
    {
        for(int i=0;i<collection.size();i++)
        {
            add(collection.getNodeByIndex(i).element.first);
        }
    }

    public void setNodeByIndex(int index, String value)
    {
        Pair pair = new Pair(value);
        Objects.checkIndex(index, size()-1);
        Node node = getNodeByIndex(index);
        node.element=pair;

    }

    @Override
    public String toString() {
        String result = "";
        Node current = head;
        while(current.next != null){
            result += current.element;
            current = current.next;
        }
        result=result+current.element;
        return "" + result;
    }

    public Iterator<Pair> iterator() {
        Node firstNode = head;
        return new Iterator<Pair>() {
            Node currentNode = null;
            @Override
            public boolean hasNext() {
                if (firstNode==null) {
                    return false;
                } else if (currentNode == null){
                    return true;
                } else if (currentNode.next == null){
                    return false;
                }
                return true;
            }
            @Override
            public Pair next() {
                if (firstNode==null){
                    throw new NoSuchElementException();
                } else if (currentNode == null){
                    this.currentNode = firstNode;
                    return currentNode.element;
                } else if (currentNode.next == null) {
                    throw new NoSuchElementException();
                }
                this.currentNode = currentNode.next;
                return currentNode.element;
            }
        };
    }
}

