package ua.univer.practice3.Task1;

import java.util.*;

public class RangedOpsIntegerSet implements Iterable<Integer> {


    private void inOrder(Node current)
    {
        if(root==null)
            return;
        if(current.left!=null)
            inOrder(current.left);
        list.add(current.element);
        if (current.right!=null)
            inOrder(current.right);
    }

    @Override
    public Iterator<Integer> iterator() {
        list.clear();
        inOrder(root);
        return list.iterator();
    }

    private static class Node {
        int element;
        Node left;
        Node right;

        public Node(int element) {
            this.element = element;
        }
    }
    private List<Integer> list = new ArrayList<Integer>();
    private Node root;

    public int size() {

        return size(root);
    }

    private int size(Node current)
    {
        if(current==null)
            return 0;
        else return size(current.left)+1 + size(current.right);
    }

    public boolean add(int element) {
        if (root == null) {
            root = new Node(element);
            return true;
        } else {
            return add(root, element);
        }
    }

    private boolean add(Node current, int element) {
        if (element < current.element) {
            if (current.left == null) {
                current.left = new Node(element);
                return true;
            } else
                return add(current.left, element);
        } else if (element > current.element) {
            if (current.right == null) {
                current.right = new Node(element);
                return true;
            } else
            {
                return add(current.right, element);
            }

        } else return false;
    }

    public boolean remove(int element) {

        if(root==null)
            return false;
        else
        {
            remove(root, element);
            return true;
        }

    }
    private static void deleteDeepest(Node current, Node delNode)
    {
        Queue<Node> q = new LinkedList<Node>();
        q.add(current);

        Node temp = null;

        while (!q.isEmpty())
        {
            temp = q.peek();
            q.remove();

            if (temp == delNode)
            {
                temp = null;
                return;

            }
            if (temp.right!=null)
            {
                if (temp.right == delNode)
                {
                    temp.right = null;
                    return;
                }
                else
                    q.add(temp.right);
            }

            if (temp.left != null)
            {
                if (temp.left == delNode)
                {
                    temp.left = null;
                    return;
                }
                else
                    q.add(temp.left);
            }
        }
    }
    private void remove(Node current, int element)
    {
        if (root.left == null && root.right == null)
        {
            if (root.element == element)
            {
                root=null;
                return;
            }
            else
                return;
        }

        Queue<Node> q = new LinkedList<Node>();
        q.add(root);
        Node temp = null, keyNode = null;

        while (!q.isEmpty())
        {
            temp = q.peek();
            q.remove();

            if (temp.element == element)
                keyNode = temp;

            if (temp.left != null)
                q.add(temp.left);

            if (temp.right != null)
                q.add(temp.right);
        }

        if (keyNode != null)
        {
            int x = temp.element;
            deleteDeepest(root, temp);
            keyNode.element = x;
        }
    }

    public boolean add(int fromInclusive, int toExclusive) {
        boolean result = true;
        for (int i = fromInclusive; i < toExclusive; i++) {
            boolean temp = add(i);
            if (!temp)
                result = false;
        }
        return result;
    }

    public boolean remove(int fromInclusive, int toExclusive) {
        boolean result = true;
        for (int i = fromInclusive; i < toExclusive; i++) {
            boolean temp = remove(i);
            if (!temp) {
                result = false;
            }
        }
        return result;
    }


}
