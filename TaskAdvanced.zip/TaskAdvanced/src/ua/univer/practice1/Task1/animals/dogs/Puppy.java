package ua.univer.practice1.Task1.animals.dogs;

public class Puppy extends Dog {

    String name;
    public Puppy (String _name)
    {
        name=_name;
    }
}
