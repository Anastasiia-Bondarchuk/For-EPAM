package ua.univer.practice1.Task1.animals.cats;

public class Kitten extends Cat{

    String name;
    public Kitten (String _name)
    {
        name=_name;
    }
}
