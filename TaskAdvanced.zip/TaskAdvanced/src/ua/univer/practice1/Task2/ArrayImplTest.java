package ua.univer.practice1.Task2;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class ArrayImplTest {

    @org.junit.jupiter.api.Test
    void add() {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        changed.add(4);
        assertEquals(changed.get(6), 4);
    }

    @org.junit.jupiter.api.Test
    void set() {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        changed.set(2,9);
        assertEquals(changed.get(2), 9);
    }

    @org.junit.jupiter.api.Test
    void get() {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        assertEquals(changed.get(2), 8);
    }

    @org.junit.jupiter.api.Test
    void indexOf() throws Exception {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        assertEquals(changed.indexOf(7), 1);
    }

    @org.junit.jupiter.api.Test
    void remove() {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        changed.remove(0);
        assertNotEquals(changed.get(0), 4);
    }

    @org.junit.jupiter.api.Test
    void clear() {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        changed.clear();
        assertEquals(changed.size(), 0);
    }

    @org.junit.jupiter.api.Test
    void size() {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>changed = new <Integer>ArrayImpl(array);
        assertEquals(changed.size(), 6);
    }
}