package ua.univer.practice1.Task2;

import java.util.Iterator;

public interface Container<T> extends Iterable<T>{

    void clear();
    int size();
    String toString();
    Iterator<T> iterator();
}
