package ua.univer.practice1.Task2;

public interface Array<T> extends Container<T>{

    void add(T element);
    void set(int index, T element);
    T get(int index);
    int indexOf(T element) throws Exception;
    void remove(int index);
}
