package ua.univer.practice1.Task1.house;

import ua.univer.practice1.Task1.animals.cats.Cat;
import ua.univer.practice1.Task1.animals.cats.Kitten;
import ua.univer.practice1.Task1.animals.dogs.Dog;
import ua.univer.practice1.Task1.animals.dogs.Puppy;

public class Main {

    public static void main(String[] args){
        Dog spike = new Dog("Spike");
        Puppy rex = new Puppy("Rex");
        Cat bohdan = new Cat("Bohdan");
        Kitten phill = new Kitten("Phill");

        House<Dog> dogHouse = new House<>();
        dogHouse.enter(spike);
        dogHouse.enter(rex);
        // dogHouse.enter(bohdan); - compilation error
        House<Cat> catHouse = new House<>();
        catHouse.enter(phill);
        catHouse.enter(bohdan);
        //catHouse.enter(rex); - compilation error

    }
}
