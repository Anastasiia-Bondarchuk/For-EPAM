package ua.univer.practice1.Task1.house;


import java.util.ArrayList;
import java.util.List;

public class House<T> {

    public final List<T> animals = new ArrayList();
    public void enter(T animal) {
        animals.add(animal);

    }

}
