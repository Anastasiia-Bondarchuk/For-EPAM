package ua.univer.practice3.Task3.SecondPart;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SortedByAbsoluteValueTest {

    @Test
    void size() {

        SortedByAbsoluteValue my = new SortedByAbsoluteValue();
        my.add(8);
        my.add(9);
        my.add(5);
        my.add(95);

        assertEquals(4, my.size());
    }

    @Test
    void add() {
        SortedByAbsoluteValue my = new SortedByAbsoluteValue();
        my.add(8);
        my.add(9);
        my.add(5);
        my.add(95);

        assertEquals(true, my.contains(5));
    }

    @Test
    void contains() {
        SortedByAbsoluteValue my = new SortedByAbsoluteValue();
        my.add(8);
        my.add(9);
        my.add(5);
        my.add(95);

        assertEquals(true, my.contains(95));
    }

    @Test
    void addCollection() {

        SortedByAbsoluteValue my = new SortedByAbsoluteValue();
        my.add(8);
        my.add(9);
        my.add(5);
        my.add(95);

        SortedByAbsoluteValue second = new SortedByAbsoluteValue();
        second.add(123);
        second.add(223);
        second.addCollection(my);

        assertEquals(true, second.contains(95));
    }

    @Test
    void delete() {

        SortedByAbsoluteValue my = new SortedByAbsoluteValue();
        my.add(8);
        my.add(9);
        my.add(5);
        my.add(95);
        my.delete(95);

        assertEquals(false, my.contains(95));
    }
}