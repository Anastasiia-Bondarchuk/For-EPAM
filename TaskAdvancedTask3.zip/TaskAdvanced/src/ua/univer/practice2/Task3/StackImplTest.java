package ua.univer.practice2.Task3;

import org.junit.jupiter.api.Test;
import ua.univer.practice2.Task1.CITY;

import java.lang.reflect.Field;

import static org.junit.jupiter.api.Assertions.*;

class StackImplTest {

    @Test
    void clear() {
        StackImpl<CITY> cities= new StackImpl<>();
        ReadAndWriteStack raws = new ReadAndWriteStack();
        raws.read(cities);
        cities.clear();
        assertEquals(null, cities.getByIndex(0));
    }

    @Test
    void size() {
        StackImpl<CITY> cities= new StackImpl<>();
        ReadAndWriteStack raws = new ReadAndWriteStack();
        raws.read(cities);
        assertEquals(7, cities.size());
    }

    @Test
    void push() {
        StackImpl<CITY> cities= new StackImpl<>();
        ReadAndWriteStack raws = new ReadAndWriteStack();
        raws.read(cities);
        cities.push(new CITY("City"));
        assertEquals("City", cities.getByIndex(7).getCity().toString());
    }

    @Test
    void pop() throws NoSuchFieldException, IllegalAccessException {
        StackImpl<CITY> cities= new StackImpl<>();
        ReadAndWriteStack raws = new ReadAndWriteStack();
        raws.read(cities);
        cities.pop();
        boolean check = false;
        for(var i: cities)
        {
            Field field = i.getClass().getDeclaredField("city");
            field.setAccessible(true);
            Object value = field.get(i);
            if(value.equals(field))
                check = true;
        }
        assertEquals(false, check);
    }

    @Test
    void top() {
        StackImpl<CITY> cities= new StackImpl<>();
        ReadAndWriteStack raws = new ReadAndWriteStack();
        raws.read(cities);
        assertEquals("Kyiv", cities.top().getCity().toString());
    }
}