package ua.univer.practice2.Task3;

import com.fasterxml.jackson.core.JsonProcessingException;
import ua.univer.practice2.Task1.CITY;
import ua.univer.practice2.Task1.ListImpl;
import ua.univer.practice2.Task2.QueueImpl;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class StackImpl<T> implements Stack<T>{

    class Node<T>
    {
        T element;
        Node<T> next;
        public Node(T element) {
            this.element = element;
        }
    }
    private Node<T> first;
    private Node<T> last;
    private int size;
    @Override
    public void clear() {
         first=last=null;
         size=0;
    }

    @Override
    public int size() {
        size = 0;
        Node<T> current = first;
        while (current != null) {
            size++;
            current = current.next;

        }
        return size;
    }

    @Override
    public Iterator<T> iterator() {
        final StackImpl<T> list = this;
        return new Iterator<T>() {

            final Node<T> first = list.first;
            Node<T> current = null;

            @Override
            public boolean hasNext() {

                if (list.first == null)
                    return false;
                else if (current == null)
                    return true;
                else if (current == list.last)
                    return false;
                return true;
            }

            @Override
            public T next() {
                if (list.first == null) throw new NoSuchElementException();
                else if (current == null) {
                    this.current = first;
                    return current.element;
                } else if (current.next == null)
                    throw new NoSuchElementException();
                this.current = current.next;
                return current.element;
            }
        };
    }

    @Override
    public void push(T element) {
        Node <T> current = new Node<T>(element);
        current.element=element;
        if(first==null && last==null)
        {
            first=last=current;
        }
        else{
            last.next=current;
            last=current;
        }

    }

    @Override
    public T pop() {
        Node<T> prev = first;
        if(first==null && last==null)
        {
            throw new NoSuchElementException("Your stack is already empty!");
        }
        else {
            while (prev.next != last) {
                prev = prev.next;
            }
            last = prev;
            last.next=null;
        }
        return prev.element;
    }

    @Override
    public T top() {
        return first.element;
    }

    public T getByIndex(int index)
    {
        Node<T> current = first;
        int count = 0;
        while (current != null) {
            if (count == index)
                return current.element;
            count++;
            current = current.next;
        }
        return null;
    }

    public void main() throws JsonProcessingException {
        StackImpl<CITY> cities= new StackImpl<>();
        ReadAndWriteStack raws = new ReadAndWriteStack();
        raws.read(cities);
        System.out.println(raws.write(cities));

        cities.clear();
        cities.push(new CITY("Tokyo"));
        cities.push(new CITY("Paris"));
        cities.push(new CITY("Berlin"));
        System.out.println(raws.write(cities));
        cities.pop();
        System.out.println(raws.write(cities));
        System.out.println(cities.top().getCity().toString());
    }
}
