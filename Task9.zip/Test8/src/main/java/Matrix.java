public class Matrix {

    final private double[][] matrix;
    final private int length;

    public int Length() {
        return length;
    }

    public Matrix(int _n) {
        length = _n;
        matrix = new double[length][length];
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length; j++) {
                matrix[i][j] = ((Math.random() * 10));
            }
        }
    }

    public Double GetIndexValue(int i, int j) {
        return matrix[i][j];
    }

    public Matrix(Matrix one) {
        length = one.length;
        matrix = new double[length][length];
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < length; j++) {
                matrix[i][j] = one.matrix[i][j];
            }
        }
    }

    public Matrix AddMatrix(Matrix two) {

        if (length != two.length) {
            throw new ArrayIndexOutOfBoundsException("Масиви мають різну довжину!");
        } else {
            Matrix newMatrix = new Matrix(length);
            for (int i = 0; i < newMatrix.length; i++) {
                for (int j = 0; j < newMatrix.length; j++) {
                    newMatrix.matrix[i][j] = two.matrix[i][j] + matrix[i][j];
                }
            }
            return newMatrix;
        }
    }

    public Matrix DeductMatrix(Matrix two) {
        if (length != two.length) {
            throw new ArrayIndexOutOfBoundsException("Масиви мають різну довжину!");
        } else {
            Matrix newMatrix = new Matrix(length);
            for (int i = 0; i < newMatrix.length; i++) {
                for (int j = 0; j < newMatrix.length; j++) {
                    newMatrix.matrix[i][j] = matrix[i][j] - two.matrix[i][j];
                }
            }
            return newMatrix;
        }
    }

    public Matrix MultiplyMatrix(Matrix two) {
        if (length != two.length) {
            throw new ArrayIndexOutOfBoundsException("Масиви мають різну довжину!");
        } else {
            Matrix newMatrix = new Matrix(length);
            for (int i = 0; i < newMatrix.length; i++) {
                for (int j = 0; j < newMatrix.length; j++) {
                    newMatrix.matrix[i][j] = two.matrix[i][j] * matrix[i][j];
                }
            }
            return newMatrix;
        }
    }
}
