public class Program {
    static void Show(Matrix one) {
        for (int i = 0; i < one.Length(); i++) {
            for (int j = 0; j < one.Length(); j++) {
                System.out.print(one.GetIndexValue(i, j) + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Matrix matrix1 = new Matrix(4);
        Show(matrix1);
        System.out.println();
        Matrix matrix2 = new Matrix(4);
        Show(matrix2);
        System.out.println();
        Matrix newMatrix = matrix1.AddMatrix(matrix2);
        Show(newMatrix);

    }
}