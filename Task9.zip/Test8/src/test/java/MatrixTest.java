import org.junit.Test;

import static org.junit.Assert.*;

public class MatrixTest {

    @Test
    public void addMatrix() {
        Matrix matrix1 = new Matrix(4);
        Matrix matrix2 = new Matrix(4);
        Matrix newMatrix = matrix1.AddMatrix(matrix2);
        assertEquals(matrix1.GetIndexValue(0, 0) + matrix2.GetIndexValue(0, 0), newMatrix.GetIndexValue(0, 0), 0.0);
        Matrix matrix3 = new Matrix(7);
        assertThrows(ArrayIndexOutOfBoundsException.class, () -> matrix1.AddMatrix(matrix3));
    }

    @Test
    public void deductMatrix() {
        Matrix matrix1 = new Matrix(5);
        Matrix matrix2 = new Matrix(5);
        Matrix newMatrix = new Matrix(matrix1.DeductMatrix(matrix2));
        assertEquals(matrix1.GetIndexValue(0, 0) - matrix2.GetIndexValue(0, 0), newMatrix.GetIndexValue(0, 0), 0.0);
    }

    @Test
    public void multiplyMatrix() {
        Matrix matrix1 = new Matrix(2);
        Matrix matrix2 = new Matrix(2);
        Matrix newMatrix = matrix1.MultiplyMatrix(matrix2);
        assertEquals(matrix1.GetIndexValue(0, 0) * matrix2.GetIndexValue(0, 0), newMatrix.GetIndexValue(0, 0), 0.0);
    }
}