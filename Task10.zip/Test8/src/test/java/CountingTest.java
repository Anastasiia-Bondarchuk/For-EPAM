import org.junit.Test;

import static org.junit.Assert.*;

public class CountingTest {
    private static final double DELTA = 1e-15;

    @Test
    public void sumArrayOfSalary() {
        Counting n = new Counting();
        n.SumArrayOfSalary();
        assertEquals(122737.98000000001, n.arrayOfSalary[0], DELTA);
    }

    @Test
    public void arrayOfSalaryFirstMonth() {
        Counting n = new Counting();
        n.ArrayOfSalaryFirstMonth();
        assertEquals(14881.55, n.arrayOfSalary[0], DELTA);
    }

    @Test
    public void arrayOfSalarySecondMonth() {
        Counting n = new Counting();
        n.ArrayOfSalarySecondMonth();
        assertEquals(52723.8, n.arrayOfSalary[0], DELTA);
    }

    @Test
    public void arrayOfSalaryThirdMonth() {
        Counting n = new Counting();
        n.ArrayOfSalaryThirdMonth();
        assertEquals(55132.63, n.arrayOfSalary[0], DELTA);
    }

    @Test
    public void theBiggest() {
        Counting n = new Counting();
        n.TheBiggest();
        assertEquals(122737.98000000001, n.salary, DELTA);
    }

    @Test
    public void arrayOfMinimumSalary() {
        Counting n = new Counting();
        n.ArrayOfMinimumSalary();
        assertEquals(25781.25, n.arrayOfSalary[0], DELTA);
    }

    @Test
    public void mediumSalaryFirstMonth() {
        Counting n = new Counting();
        n.MediumSalaryFirstMonth();
        assertEquals(13750.0, n.salary, DELTA);
    }

    @Test
    public void mediumSalarySecondMonth() {
        Counting n = new Counting();
        n.MediumSalarySecondMonth();
        assertEquals(15125.0, n.salary, DELTA);
    }

    @Test
    public void mediumSalaryThirdMonth() {
        Counting n = new Counting();
        n.MediumSalaryThirdMonth();
        assertEquals(14630.0, n.salary, DELTA);
    }

    @Test
    public void theBiggestMediumSalary() {
        Counting n = new Counting();
        n.TheBiggestMediumSalary();
        assertEquals(15125.0, n.salary, DELTA);
    }
}