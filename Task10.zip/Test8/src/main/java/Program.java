import java.util.ArrayList;

public class Program {

    public static void main(String [] args)
    {
        Counting n = new Counting();

    }


}
