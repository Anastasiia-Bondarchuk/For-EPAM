import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class Counting {

    String name;
    double salary;
    double[] arrayOfSalary;
    String [] names;
    private InputOperations IO1;
    private InputOperations IO2;
    private InputOperations IO3;
    private String location = "C:\\Users\\Настя\\Desktop\\Money1.xls";
    public Counting() {
        IO1 = new InputOperations(location);
        int count=0;
        for(var i: IO1.getNames())
        {
            count++;
        }
        names = new String[count];
        count=0;
        for(var i: IO1.getNames())
        {
            names[count] =i;
            count++;
        }
        location = "C:\\Users\\Настя\\Desktop\\Money2.xls";
        IO2 = new InputOperations(location);
        location = "C:\\Users\\Настя\\Desktop\\Money3.xls";
        IO3 = new InputOperations(location);
        arrayOfSalary = new double[names.length];
        for(int i=0;i<names.length;i++)
        {
            IO1.getSalary().set(i, IO1.getSalary().get(i).replace(',', '.'));
            IO2.getSalary().set(i, IO2.getSalary().get(i).replace(',', '.'));
            IO3.getSalary().set(i, IO3.getSalary().get(i).replace(',', '.'));
        }

    }
    public void SumArrayOfSalary()
    {
        for (int i = 0; i < names.length; i++) {
            double sum = Double.parseDouble(IO1.getSalary().get(i)) + Double.parseDouble(IO2.getSalary().get(i)) + Double.parseDouble(IO3.getSalary().get(i));
            arrayOfSalary[i] = sum;
        }
    }
    public void ArrayOfSalaryFirstMonth()
    {
        for (int i = 0; i < names.length; i++) {
            arrayOfSalary[i] = Double.parseDouble(IO1.getSalary().get(i));
        }
    }
    public void ArrayOfSalarySecondMonth()
    {
        for (int i = 0; i < names.length; i++) {
            arrayOfSalary[i] = Double.parseDouble(IO2.getSalary().get(i));
        }
    }
    public void ArrayOfSalaryThirdMonth()
    {
        for (int i = 0; i < names.length; i++) {
            arrayOfSalary[i] = Double.parseDouble(IO3.getSalary().get(i));
        }
    }
    public void TheBiggest()
    {
        SumArrayOfSalary();
        double max = arrayOfSalary[0];
        for (int i = 1; i < arrayOfSalary.length; i++)
        {
            if (arrayOfSalary[i] > max)
                max = arrayOfSalary[i];
        }
        int count1 =0;
        for(var i: arrayOfSalary)
        {
            if(i==max)
                break;
            count1++;
        }
        salary = max;
        name = names[count1];
    }

    public void ArrayOfMinimumSalary()
    {
        SumArrayOfSalary();
        double temp;
        String tempNames;
        for (int i = 0; i < arrayOfSalary.length; i++) {
            for (int j =i+1; j < arrayOfSalary.length; j++) {
                if (arrayOfSalary[j] < arrayOfSalary[i]) {
                    temp = arrayOfSalary[i];
                    arrayOfSalary[i] = arrayOfSalary[j];
                    arrayOfSalary[j] = temp;
                    tempNames = names[i];
                    names[i] = names[j];
                    names[j] = tempNames;
                }
            }
        }
    }
    public void ArrayOfMediumSalary()
    {
        SumArrayOfSalary();
        double sumsalary =0;
        for (int i = 0; i < arrayOfSalary.length; i++)
        {
            sumsalary += arrayOfSalary[i];
        }
        salary = sumsalary/arrayOfSalary.length;
        for (int i = 0; i < arrayOfSalary.length; i++)
        {
            if(arrayOfSalary[i]>(salary-salary*0.2) && arrayOfSalary[i]<(salary+salary*0.2))
            {
                System.out.println(names[i] + " " + arrayOfSalary[i]);
            }
        }
    }
    public void MediumSalaryFirstMonth()
    {
        ArrayOfSalaryFirstMonth();
        double temp;
        String tempNames;
        for (int i = 0; i < arrayOfSalary.length; i++) {
            for (int j =i+1; j < arrayOfSalary.length; j++) {
                if (arrayOfSalary[j] < arrayOfSalary[i]) {
                    temp = arrayOfSalary[i];
                    arrayOfSalary[i] = arrayOfSalary[j];
                    arrayOfSalary[j] = temp;
                    tempNames = names[i];
                    names[i] = names[j];
                    names[j] = tempNames;
                }
            }
        }
        name = names[arrayOfSalary.length/2];
        salary = arrayOfSalary[arrayOfSalary.length/2];
    }
    public void MediumSalarySecondMonth()
    {
        ArrayOfSalarySecondMonth();
        double temp;
        String tempNames;
        for (int i = 0; i < arrayOfSalary.length; i++) {
            for (int j =i+1; j < arrayOfSalary.length; j++) {
                if (arrayOfSalary[j] < arrayOfSalary[i]) {
                    temp = arrayOfSalary[i];
                    arrayOfSalary[i] = arrayOfSalary[j];
                    arrayOfSalary[j] = temp;
                    tempNames = names[i];
                    names[i] = names[j];
                    names[j] = tempNames;
                }
            }
        }
        name = names[arrayOfSalary.length/2];
        salary = arrayOfSalary[arrayOfSalary.length/2];
    }
    public void MediumSalaryThirdMonth()
    {
        ArrayOfSalaryThirdMonth();
        double temp;
        String tempNames;
        for (int i = 0; i < arrayOfSalary.length; i++) {
            for (int j =i+1; j < arrayOfSalary.length; j++) {
                if (arrayOfSalary[j] < arrayOfSalary[i]) {
                    temp = arrayOfSalary[i];
                    arrayOfSalary[i] = arrayOfSalary[j];
                    arrayOfSalary[j] = temp;
                    tempNames = names[i];
                    names[i] = names[j];
                    names[j] = tempNames;
                }
            }
        }
        name = names[arrayOfSalary.length/2];
        salary = arrayOfSalary[arrayOfSalary.length/2];
    }
    public void TheBiggestMediumSalary()
    {
        MediumSalaryFirstMonth();
        String name1 = name;
        double salary1 = salary;
        MediumSalarySecondMonth();
        String name2 = name;
        double salary2 = salary;
        MediumSalaryThirdMonth();
        String name3 = name;
        double salary3 = salary;
        double []ArrSalary={salary1,salary2,salary3};
        String []ArrNames = {name1, name2,name3};
        double thebiggest = ArrSalary[0];
        for (int i = 1; i < ArrSalary.length; i++)
        {
            if (ArrSalary[i] > thebiggest)
                thebiggest = ArrSalary[i];
        }
        int count1 =0;
        for(var i: ArrSalary)
        {
            if(i==thebiggest)
                break;
            count1++;
        }
        salary = thebiggest;
        name = ArrNames[count1];
    }
}
