import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;

import java.io.FileInputStream;
import java.util.ArrayList;

public class InputOperations {

    public ArrayList<String> getNames() {
        return names;
    }

    public ArrayList<String> getSalary() {
        return salary;
    }

    private ArrayList<String> names = new ArrayList<>();
    private ArrayList<String> salary = new ArrayList<>();

    public InputOperations(String path) {

        try {
            FileInputStream file = new FileInputStream(path);
            HSSFWorkbook wb = new HSSFWorkbook(file);
            DataFormatter dataFormatter = new DataFormatter();
            final int amountOfpeople = 14;
                for(int j=1; j<=amountOfpeople; j++)
                {
                    names.add(wb.getSheetAt(0).getRow(j).getCell(1).getStringCellValue());
                    String val = dataFormatter.formatCellValue(wb.getSheetAt(0).getRow(j).getCell(3));

                    salary.add(val);
                }
            file.close();

        }
        catch (Exception e)
        {
            System.out.println("Cannot ope file");
        }
    }
}
