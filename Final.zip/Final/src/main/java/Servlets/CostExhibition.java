package Servlets;

import Classes.ServerAtributes.Exhibition;
import IDAO.AccessToDataBaseExhibitions;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class CostExhibition extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AccessToDataBaseExhibitions access = new AccessToDataBaseExhibitions();
        int minCost = Integer.parseInt(req.getParameter("minCost"));
        int maxCost = Integer.parseInt(req.getParameter("maxCost"));

        List<Exhibition> exhibitions = access.getExhibitionsDAO().getExhibitionByCost(minCost,maxCost);

        if(exhibitions!=null)
        {
            req.getSession().setAttribute("exhibitions", exhibitions);
            resp.sendRedirect("exhibitionsFilter.jsp");
        }else{
            req.getRequestDispatcher("exhibitionsUser.jsp").forward(req,resp);
        }
    }

}
