package Servlets;

import Classes.ServerAtributes.Exhibition;
import IDAO.AccessToDataBaseExhibitions;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DelExhibition extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AccessToDataBaseExhibitions access = new AccessToDataBaseExhibitions();
        String name = req.getParameter("name");

        Exhibition exhibition = access.DeleteExhibition(name);

        if(exhibition!=null)
        {
            req.getSession().setAttribute("exhibition", exhibition);
            resp.sendRedirect("exhibitions.jsp");
        }else{
            req.getRequestDispatcher("deleteExhibition.jsp").forward(req,resp);
        }
    }
}
