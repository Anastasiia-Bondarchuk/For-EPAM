package Servlets;

import Classes.ServerAtributes.Exhibition;
import IDAO.AccessToDataBaseExhibitions;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AddExhibition extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AccessToDataBaseExhibitions access = new AccessToDataBaseExhibitions();
        String name = req.getParameter("name");
        String theme = req.getParameter("theme");
        String start = req.getParameter("start");
        String end = req.getParameter("end");
        Integer hall = Integer.parseInt(req.getParameter("hall"));
        Integer cost = Integer.parseInt(req.getParameter("cost"));

        Exhibition exhibition = access.AddExhibition(name,hall,cost,start,end,theme);

        if(exhibition!=null)
        {
            req.getSession().setAttribute("exhibition", exhibition);
            resp.sendRedirect("exhibitions.jsp");
        }else{
            req.getRequestDispatcher("addExhibition.jsp").forward(req,resp);
        }
    }
}
