package Servlets;

import Classes.Accounts.User;
import IDAO.AccessToDataBase;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Registration extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        AccessToDataBase access = new AccessToDataBase();
        String login = req.getParameter("login");
        String password = req.getParameter("password");
        User user = access.RegisterUser(login, password);
        if(user!=null)
        {
            req.getSession().setAttribute("user", user); //Put user into session
            req.getSession().setAttribute("id", user.getId());
            resp.sendRedirect("userMenu.jsp");
        }else{
            req.setAttribute("error", "Too long login or password!");
            req.getRequestDispatcher("registration.jsp").forward(req,resp);
        }
        }

    }

