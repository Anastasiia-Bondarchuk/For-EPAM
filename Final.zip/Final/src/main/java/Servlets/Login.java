package Servlets;

import Classes.Accounts.Admin;
import Classes.Accounts.User;
import IDAO.AccessToDataBase;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class Login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("login");
        String password = req.getParameter("password");

        AccessToDataBase access = new AccessToDataBase();
        User user = access.getUsers().getUserByLoginPassword(name,password);

        if(user!=null&& user.getRole()== User.ROLE.USER)
        {
            HttpSession session = req.getSession();
            session.setAttribute("user", user); //Put user into session
            session.setAttribute("id", user.getId());
            resp.sendRedirect("userMenu.jsp");
        }else if(user!=null && user.getRole()== User.ROLE.ADMIN)
        {
            HttpSession session = req.getSession();
            session.setAttribute("user", user); //Put user into session
            session.setAttribute("id", user.getId());
            resp.sendRedirect("adminMenu.jsp");
        }
        else{
            req.setAttribute("error", "Unknown login, try again!");
            req.getRequestDispatcher("login.jsp").forward(req,resp);
        }
    }
}


