package Servlets;

import Classes.ServerAtributes.Exhibition;
import IDAO.AccessToDataBaseExhibitions;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class ThemeExhibition extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        AccessToDataBaseExhibitions access = new AccessToDataBaseExhibitions();
        String theme = req.getParameter("theme");

        List<Exhibition> exhibitions = access.getExhibitionsDAO().getExhibitionByTheme(theme);

        if(exhibitions!=null)
        {
            req.getSession().setAttribute("exhibitions", exhibitions);
            resp.sendRedirect("exhibitionsFilter.jsp");
        }else{
            req.getRequestDispatcher("exhibitionsUser.jsp").forward(req,resp);
        }
    }
}
