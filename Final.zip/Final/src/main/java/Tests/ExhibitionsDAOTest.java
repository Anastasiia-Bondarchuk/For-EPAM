package Tests;

import Classes.ServerAtributes.Exhibition;
import IDAO.AccessToDataBaseExhibitions;
import IDAO.ExhibitionsDAO;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExhibitionsDAOTest {

    AccessToDataBaseExhibitions access = new AccessToDataBaseExhibitions();
    Exhibition ex = new Exhibition("Name", 2, 1200,"2021-12-31", "2022-05-03",
            "Inspired by great artists");

    @org.junit.jupiter.api.Test
    void addExhibition() {

        boolean check = false;
        access.getExhibitionsDAO().addExhibition(ex);
        for(Exhibition _ex:access.getExhibitionsDAO().getExhibitions())
        {
            if(_ex.getName().equals(ex.getName()))
            {
                check=true;
            }
        }
        assertEquals(true, check);
        access.DeleteExhibition(ex.getName());
    }

    @org.junit.jupiter.api.Test
    void deleteExhibition() {
        boolean check = false;
        access.getExhibitionsDAO().addExhibition(ex);
        for(Exhibition _ex:access.getExhibitionsDAO().getExhibitions())
        {
            if(_ex.getName().equals(ex.getName()))
            {
                check=true;
            }
        }
        assertEquals(true, check);
        access.DeleteExhibition(ex.getName());
    }

    @org.junit.jupiter.api.Test
    void getExhibitionByCost() {

        boolean check = false;
        access.getExhibitionsDAO().addExhibition(ex);
        List<Exhibition> test = access.getExhibitionsDAO().getExhibitionByCost(1199,1201);

        for(Exhibition _ex:test)
        {
            if(_ex.getName().equals(ex.getName()))
            {
                check=true;
            }
        }

        assertEquals(true, check);
        access.DeleteExhibition(ex.getName());
    }

    @org.junit.jupiter.api.Test
    void getExhibitionByDate() {

        boolean check = false;
        access.getExhibitionsDAO().addExhibition(ex);
        List<Exhibition> test = access.getExhibitionsDAO().getExhibitionByDate("2022-04-03");

        for(Exhibition _ex:test)
        {
            if(_ex.getName().equals(ex.getName()))
            {
                check=true;
            }
        }

        assertEquals(true, check);
        access.DeleteExhibition(ex.getName());
    }

    @org.junit.jupiter.api.Test
    void getExhibitionByTheme() {

        boolean check = false;
        access.getExhibitionsDAO().addExhibition(ex);
        List<Exhibition> test = access.getExhibitionsDAO().getExhibitionByTheme("Inspired by great artists");

        for(Exhibition _ex:test)
        {
            if(_ex.getName().equals(ex.getName()))
            {
                check=true;
            }
        }

        assertEquals(true, check);
        access.DeleteExhibition(ex.getName());
    }

    @org.junit.jupiter.api.Test
    void getExhibitions() {

        ExhibitionsDAO exDAO = access.getExhibitionsDAO();

        assertEquals(true, exDAO!=null);
    }
}