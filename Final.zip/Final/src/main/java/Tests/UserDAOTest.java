package Tests;

import Classes.Accounts.User;
import IDAO.AccessToDataBase;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserDAOTest {

    AccessToDataBase access = new AccessToDataBase();

    @Test
    void getUserByID()
    {
        User user = access.getUsers().getById(2);
        boolean check=false;
        for(User u: access.getUsers().getStore())
        {
            if(u.getLogin().equals(user.getLogin())&&u.getId()== user.getId());
                check=true;
        }
        assertEquals(true, check);
    }

    @Test
    void getUserByLoginPassword() {
        User user = access.getUsers().getUserByLoginPassword("Klyde", "12345");
        boolean check=false;
        for(User u: access.getUsers().getStore())
        {
            if(u.getLogin().equals(user.getLogin()))
                check=true;
        }
        assertEquals(true, check);
    }

    @Test
    void add() {
        User user= access.RegisterUser("user", "password");
        boolean check=false;
        for(User u: access.getUsers().getStore())
        {
            if(u.getLogin().equals(user.getLogin()))
                check=true;
        }
        assertEquals(true, check);
    }

    @Test
    void getRoleByLogin() {

        User.ROLE role = access.getUsers().getRoleByLogin("Klyde");
        assertEquals(User.ROLE.USER, role);
    }

    @Test
    void userExists() {

        boolean check = access.getUsers().userExists("Klyde");
        assertEquals(true, check);
    }
}