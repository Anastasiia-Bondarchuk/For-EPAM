package IDAO;

import Classes.ServerAtributes.Exhibition;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExhibitionsDAO {

    private final List<Exhibition> exhibitions = new ArrayList<>();

    public boolean addExhibition(Exhibition _exhibition)
    {
        for(Exhibition exhibition: exhibitions)
        {
            if(exhibition.getName().equals(_exhibition.getName()))
                return false;
        }
        return exhibitions.add(_exhibition);
    }

    public Exhibition deleteExhibition(String name)
    {
        for(Exhibition exhibition: exhibitions)
        {
            if(exhibition.getName().equals(name))
            {
                exhibitions.remove(exhibition);
                return exhibition;
            }
        }
        return null;
    }

    public List<Exhibition> getExhibitionByCost(int mincost, int maxcost)
    {
        List<Exhibition> temp = new ArrayList<>();
        for(Exhibition exhibition: exhibitions)
        {
            if(exhibition.getCost()>=mincost && exhibition.getCost()<=maxcost)
            {
                temp.add(exhibition);
            }
        }
        if(temp.isEmpty())
            return null;
        else return temp;
    }


    public List<Exhibition> getExhibitionByDate(String date)
    {
        List <Exhibition> ourList = new ArrayList<>();


        for(Exhibition exhibition: exhibitions)
        {
            List <String> temp = new ArrayList<>();
            temp.add(date);
            temp.add(exhibition.getStart());
            temp.add(exhibition.getEnd());

            Collections.sort(temp);

            if(temp.get(1).equals(date))
                ourList.add(exhibition);
        }
        if(ourList.isEmpty())
            return null;
        else return ourList;
    }

    public  List<Exhibition> getExhibitionByTheme(String theme)
    {
        List<Exhibition> temp = new ArrayList<>();
        for(Exhibition exhibition: exhibitions)
        {
            if(exhibition.getTheme().equals(theme))
                temp.add(exhibition);
        }
        if(temp.isEmpty())
            return null;
        else return temp;
    }

    public List<Exhibition> getExhibitions() {
        return exhibitions;
    }
}
