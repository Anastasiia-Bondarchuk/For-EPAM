package IDAO;

import Classes.Accounts.User;

import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private final List<User> store = new ArrayList<>();

    public User getById(int id)
    {
        User temp= new User();
        for(User user: store)
        {
            if(user.getId()==id)
                temp = user;
        }
         return temp;
    }

    public User getUserByLoginPassword(final String login, final String password)
    {
        for(User user: store)
        {
            if(user.getLogin().equals(login) && user.getPassword().equals(password))
                return user;
        }
        return null;
    }

    public boolean add(final User _user)
    {
        for (User user: store) {
            if(user.getLogin().equals(_user.getLogin()))
                return false;
        }
        return store.add(_user);
    }

    public User.ROLE getRoleByLogin(final String login)
    {
        User.ROLE temp = User.ROLE.UNKNOWN;
        for(User user: store)
        {
            if(user.getLogin().equals(login))
                return user.getRole();
        }
        return temp;
    }

    public boolean userExists(final String login)
    {
        for(User user:store)
        {
            if(user.getLogin().equals(login))
                return true;
        }
        return false;
    }

    public List<User> getStore() {
        return store;
    }
}
