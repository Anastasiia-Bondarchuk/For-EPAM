package IDAO;

import Classes.ServerAtributes.Exhibition;

import java.sql.*;

public class AccessToDataBaseExhibitions {

    private static final String URL = "jdbc:mysql://localhost:3306/websitedatabase";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1234";

    ExhibitionsDAO exhibitionsDAO = new ExhibitionsDAO();

    public AccessToDataBaseExhibitions()
    {
        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement=null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from exhibitions");

            while(resultSet.next())
            {
                Exhibition exhibition = new Exhibition(resultSet.getString("name"), resultSet.getInt("hall"),
                        resultSet.getInt("cost"), resultSet.getString("start"), resultSet.getString("end"),
                        resultSet.getString("theme"));
                exhibitionsDAO.addExhibition(exhibition);
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }}

    public Exhibition AddExhibition(String name, int hall, int cost, String start, String end,String theme)
    {
        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;

        Exhibition exhibition = new Exhibition(name, hall,cost, start,end,theme);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
            PreparedStatement ps = null;

            if(exhibitionsDAO.getExhibitions().isEmpty())
            {
                ps = conn.prepareStatement("INSERT INTO exhibitions " +
                        "(id, name, hall,cost,start,end,theme) VALUES ('"+ 1 +"', '"+name
                        +"', '"+hall+"', '"+cost+"', '"+start+"', '"+end+"', '"+theme+"')");
            }else ps = conn.prepareStatement("INSERT INTO exhibitions " +
                    "(name, hall,cost,start,end,theme) VALUES ('"+name
                    +"', '"+hall+"', '"+cost+"', '"+start+"', '"+end+"', '"+theme+"')");
                ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(name.length()<=45&&start.length()<=10&&end.length()<=10&&hall<=10&&cost>0&&theme.length()<=40)
            {
                exhibitionsDAO.addExhibition(exhibition);
                return exhibition;
            }
            return null;
        }
    }

    public Exhibition DeleteExhibition(String name)
    {
        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from exhibitions where name = '" + name + "'");
            resultSet.next();
            int id =resultSet.getInt("id");
            String sql = "DELETE FROM exhibitions WHERE id = ";
            PreparedStatement ps = connection.prepareStatement(sql+id);
            ps.executeUpdate();
            Exhibition exhibition= exhibitionsDAO.deleteExhibition(name);
            if(exhibition!=null)
                return exhibition;

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }

    public ExhibitionsDAO getExhibitionsDAO() {
        return exhibitionsDAO;
    }
}
