package IDAO;

import Classes.Accounts.Admin;
import Classes.Accounts.User;

import java.sql.*;

public class AccessToDataBase {

    private static final String URL = "jdbc:mysql://localhost:3306/websitedatabase";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1234";

    private UserDAO users = new UserDAO();

    public AccessToDataBase()
    {
        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement=null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from users");

            while(resultSet.next())
            {
                User user = new User(resultSet.getString("login"), resultSet.getString("password"));
                user.setId(resultSet.getInt("id"));
                user.setRole(User.ROLE.USER);
                users.add(user);
            }
            resultSet = null;
            statement=null;
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from admins");

            while(resultSet.next())
            {
                Admin admin = new Admin(resultSet.getString("login"), resultSet.getString("password"));
                admin.setId(resultSet.getInt("id"));
                admin.setRole(User.ROLE.ADMIN);
                users.add(admin);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

    }}

    public User RegisterUser(String name, String password)
    {
        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;

        User user = new User(name, password);

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL,USERNAME,PASSWORD);
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (login, password) VALUES ('"+name
                    +"', '"+password+"')");
            ps.executeUpdate();
            resultSet = statement.executeQuery("select * from users where login = '"+name+"'");
            user.setId(resultSet.getInt("id"));
            user.setRole(User.ROLE.USER);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        if(name.length()<=10 && password.length()<=8)
        {
            users.add(user);
            return user;
        }
          return null;
    }
}


    public UserDAO getUsers() {
        return users;
    }
}






