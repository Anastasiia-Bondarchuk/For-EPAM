package Classes.Accounts;

import Classes.ServerAtributes.Card;
import Classes.ServerAtributes.Exhibition;

import java.util.ArrayList;
import java.util.List;

public class User {
    private int id;
    private String login;
    private Card card;
    private String password;
    ROLE role;

    public User(){};

    public User(String login, String password) {
        this.login = login;
        this.password = password;
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }

    public void setRole(ROLE role) {
        this.role = role;
    }

    public ROLE getRole() {
        return role;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }


    public void setPassword(String password) {
        this.password = password;
    }
    public enum ROLE{
        USER, ADMIN, UNKNOWN
    }
}
