package Classes.ServerAtributes;

public class Exhibition {

    private String name;
    private int hall;
    private int cost;
    private String start;
    private String end;
    private String theme;

    public Exhibition(String name, int hall, int cost, String start, String end, String theme) {
        this.name = name;
        this.hall = hall;
        this.cost = cost;
        this.start = start;
        this.end = end;
        this.theme=theme;

    }

    public String getName() {
        return name;
    }

    public String getTheme() {
        return theme;
    }

    public int getHall() {
        return hall;
    }

    public int getCost() {
        return cost;
    }

    public String getStart() {
        return start;
    }

    public String getEnd() {
        return end;
    }

    @Override
    public String toString() {

        return "Name: "+name + "\nTopic: "+theme+"\nHall: "+hall+"\nCost: "+cost+"\nDuration: "+start+" - "+end;
    }
}
