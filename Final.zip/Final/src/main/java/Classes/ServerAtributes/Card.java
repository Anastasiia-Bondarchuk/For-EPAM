package Classes.ServerAtributes;


public class Card {

    private String nameExhibition;
    private int quantity;

    public Card(String nameExhibition, int quantity) {
        this.nameExhibition = nameExhibition;
        this.quantity = quantity;
    }

    public String getNameExhibition() {
        return nameExhibition;
    }

    public void setNameExhibition(String nameExhibition) {
        this.nameExhibition = nameExhibition;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Card() {
    }
}
