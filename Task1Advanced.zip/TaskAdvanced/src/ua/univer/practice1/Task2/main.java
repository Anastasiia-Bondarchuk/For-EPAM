package ua.univer.practice1.Task2;

import java.util.Iterator;

public class main {

    public static void main(String [] args) throws Exception {
        Object []array = new Object[]{4,7,8,5,4,3};
        ArrayImpl <Integer>newArray = new <Integer>ArrayImpl(array);
        newArray.set(2,9);
        System.out.println(newArray.toString());
        newArray.add(81);
        System.out.println(newArray.toString());
        System.out.println(newArray.get(1).toString());
        System.out.println(newArray.indexOf(9));
        newArray.remove(4);
        System.out.println(newArray.toString());
    }
}
