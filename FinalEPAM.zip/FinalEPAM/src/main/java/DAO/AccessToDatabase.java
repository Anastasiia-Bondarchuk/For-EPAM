package DAO;

import java.io.Serializable;
import java.util.ArrayList;
import java.sql.*;


public class AccessToDatabase implements Serializable {


    private static final String URL = "jdbc:Mysql://localhost:3306/world";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1234";

    public CountryIDAOimpl getCountries() {
        return countries;
    }

    private CountryIDAOimpl countries = new CountryIDAOimpl();

    public ArrayList<City> getAllCities() {
        return AllCities;
    }

    private ArrayList<City> AllCities = new ArrayList<>();

    public AccessToDatabase() {
        Connection connection = null;
        ResultSet resultSet = null;
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from city");

            while (resultSet.next()) {
                AllCities.add(new City(resultSet.getString("Name"), resultSet.getInt("ID"), resultSet.getInt("Population"), resultSet.getString("IsCapital"), resultSet.getInt("CountryCode")));
            }
            resultSet = statement.executeQuery("select * from country");

            while (resultSet.next()) {
                countries.add(new Country(resultSet.getString("Name"), resultSet.getInt("Code")));

            }
            for (var iCountry : countries.getAll()) {
                for (var jCity : AllCities) {
                    if (jCity.getCountryCode() == iCountry.getId()) {
                        iCountry.add(jCity);
                    }
                }
            }
        } catch (SQLException sqlEx) {
            sqlEx.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void addCountry(Country country) {

        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            int count = 0;
            for (var item : countries.getAll()) {
                if (item.getName().compareTo(country.getName()) == 0)
                    count++;
            }
            if (count == 0) {
                statement.executeUpdate("INSERT INTO country (Name) VALUES('" + country.getName() + "')");
                resultSet = statement.executeQuery("select * from country where Name = '" + country.getName() + "'");
                while (resultSet.next()) {
                    country.setId(resultSet.getInt("Code"));
                }
                countries.add(country);
            } else {
                count = 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public void addCity(City city) {

        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            int count = 0;
            for (var item : AllCities) {
                if (item.getName().compareTo(city.getName()) == 0)
                    count++;
            }
            if (count == 0) {
                statement.executeUpdate("INSERT INTO city (Name, Population, CountryCode, IsCapital) VALUES('" + city.getName() + "'," + city.getPopulation() + "," + city.getCountryCode() + ", '" + city.getIsCapital() + "')");
                resultSet = statement.executeQuery("select * from city where Name = '" + city.getName() + "'");
                while (resultSet.next()) {
                    city.setId(resultSet.getInt("ID"));
                }
                AllCities.add(city);
            } else {
                count = 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    public void deleteCountry(Country country) {

        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from country where Name = '" + country.getName() + "'");
            while (resultSet.next()) {
                country.setId(resultSet.getInt("Code"));
            }

            statement.executeUpdate("DELETE FROM country WHERE Code = " + country.getId());
            countries.delete(country);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void deleteCity(City city) {

        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;
        try {
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from city where Name = '" + city.getName() + "'");
            while (resultSet.next()) {
                city.setId(resultSet.getInt("ID"));
            }
            statement.executeUpdate("DELETE FROM city WHERE ID = " + city.getId());

            for (City newcity : new ArrayList<>(AllCities)) {
                if (newcity.getName().compareTo(city.getName()) == 0)
                    AllCities.remove(newcity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void updateCountry(Country country, String name) {

        boolean check1 = true;
        for (var i : getCountries().getAll()) {
            if (i.getName().compareTo(name) == 0)
                check1 = false;
        }
        if (check1) {
            Connection connection = null;
            ResultSet resultSet = null;
            Statement statement = null;

            boolean check = true;
            for (var i : getCountries().getAll()) {
                if (i.getName().compareTo(country.getName()) == 0)
                    check = false;
            }
            if (!check) {
                try {
                    connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                    statement = connection.createStatement();
                    resultSet = statement.executeQuery("select * from country where Name = '" + country.getName() + "'");
                    while (resultSet.next()) {
                        country.setId(resultSet.getInt("Code"));
                    }
                    countries.update(country, name);
                    statement.executeUpdate("UPDATE country SET Name ='" + name + "' WHERE Code =" + country.getId());

                } catch (SQLException e) {
                    e.printStackTrace();
                } finally {
                    if (resultSet != null) {
                        try {
                            resultSet.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        try {
                            connection.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                    if (statement != null) {
                        try {
                            statement.close();
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }

        }
    }

    public void updateCity(City city, String name) {

        boolean check1 = true;
        for (var i : getCountries().getAll()) {
            if (i.getName().compareTo(name) == 0)
                check1 = false;
        }
        if (check1) {
            Connection connection = null;
            ResultSet resultSet = null;
            Statement statement = null;
            try {
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                statement = connection.createStatement();
                resultSet = statement.executeQuery("select * from city where Name = '" + city.getName() + "'");
                while (resultSet.next()) {
                    city.setId(resultSet.getInt("ID"));
                }
                City newCity = new City(city);
                newCity.setName(name);
                int index = 0;
                for (var i : AllCities) {
                    if (i.getName().compareTo(city.getName()) == 0)
                        break;
                    index++;
                }
                AllCities.set(index, newCity);
                statement.executeUpdate("UPDATE city SET Name ='" + name + "' WHERE ID =" + city.getId());

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                if (resultSet != null) {
                    try {
                        resultSet.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
    }

    public Country FindCountry(String name) {

        int count = 0;
        var forReturn = new Country();
        for (var i : countries.getAll()) {
            if (i.getName().compareTo(name) == 0) {
                forReturn = i;
                count++;
                break;
            }
        }
        if (count == 0)
            return null;
        else return forReturn;

    }

    public City FindCity(String name) {
        int count = 0;
        var forReturn = new City();
        for (var i : AllCities) {
            if (i.getName().compareTo(name) == 0) {
                forReturn = i;
                count++;
                break;
            }
        }
        if (count == 0)
            return null;
        else return forReturn;
    }

    public ArrayList<City> AllCitiesWithCode(int CountryCode) {
        ArrayList<City> MyList = new ArrayList<>();
        for (var i : AllCities) {
            if (i.getCountryCode() == CountryCode) {
                MyList.add(i);
            }
        }
        return MyList;
    }

    public ArrayList<Country> AllCountries() {
        ArrayList<Country> MyList = new ArrayList<>();
        for (var i : countries.getAll()) {
            MyList.add(i);
        }
        return MyList;
    }

}
