package DAO;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CountryIDAOimpl implements IDAO<Country>, Serializable {


    private List<Country> countries = new ArrayList<>();

    public CountryIDAOimpl(List<Country> countries) {
        this.countries = countries;
    }
    public CountryIDAOimpl() {
    }

    @Override
    public List<Country> getAll() {
        return countries;
    }

    public Country getCountry(int index) {
        return countries.get(index-1);
    }

    @Override
    public void add(Country country) {

        countries.add(country);
    }

    @Override
    public void update(Country country, String name) {

        Country newCountry = new Country (country);
        newCountry.setName(name);
        int index =0;
        for (var i: countries) {
            if(i.getName().compareTo(country.getName())==0)
            break;
            index++;
        }
        countries.set(index, newCountry);
    }

    @Override
    public void delete(Country country) {
        for(Country newcountry : new ArrayList<>(countries))
        {
            if(newcountry.getName().compareTo(country.getName())==0)
                countries.remove(newcountry);
        }
    }
}

