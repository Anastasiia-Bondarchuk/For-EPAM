package DAO;

import java.io.Serializable;
import java.util.ArrayList;

public class Country implements IDAO<City>, Serializable {

    private String name;
    private int id;
    private ArrayList<City> cities = new ArrayList<>();

    public Country()
    {}

    public Country(Country country) {
        this.name = country.name;
        this.id = country.id;
    }

    public Country(String name, int id) {
        this.name = name;
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }
    @Override
    public ArrayList<City> getAll() {
        return cities;
    }

    @Override
    public void add(City city){
        cities.add(city);
    }

    @Override
    public void update(City city, String name) {
        city.setName(name);
    }


    @Override
    public void delete(City city) {
        for(City newcity : new ArrayList<>(cities))
        {
            if(newcity.getName().compareTo(city.getName())==0)
                cities.remove(newcity);
        }

    }
}
