package DAO;

import java.io.Serializable;

public class City implements Serializable {

    private String name;
    private int id;
    private int population;
    private String isCapital;
    private int CountryCode;

    public City(String name, int id, int population, String isCapital, int BelongsToCountry) {
        this.name = name;
        this.id = id;
        this.population = population;
        this.isCapital = isCapital;
        this.CountryCode = BelongsToCountry;
    }
    public City(){}

    public City(City city)
    {
        name = city.getName();
        id = city.getId();
        population = city.getPopulation();
        isCapital = city.getIsCapital();
        CountryCode = city.getCountryCode();
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public int getPopulation() {
        return population;
    }

    public String getIsCapital() {
        return isCapital;
    }

    public int getCountryCode() {
        return CountryCode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

}

