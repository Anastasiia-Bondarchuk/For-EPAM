package DAO;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.*;

public class Serialization {

    private AccessToDatabase DeserializedFile;

    public AccessToDatabase getDeserializedFile() {
        return DeserializedFile;
    }

    public void Serialize(AccessToDatabase access)
    {
        try {
            XMLEncoder oos = new XMLEncoder(new BufferedOutputStream(new FileOutputStream("Map.xml")));
            oos.writeObject(access);
            oos.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void Deserialize()
    {
        XMLDecoder oos;
        try {
            oos = new XMLDecoder(new BufferedInputStream(new FileInputStream("Map.xml")));
            DeserializedFile = (AccessToDatabase)oos.readObject();
            oos.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

}
