package PL;

import BLL.Menu;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Menu menu = new Menu();
        menu.MainMenu();
    }
}
