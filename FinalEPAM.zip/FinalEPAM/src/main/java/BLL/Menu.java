package BLL;

import DAO.AccessToDatabase;
import DAO.Serialization;

import java.io.IOException;
import java.util.Scanner;

public class Menu {
    AccessToDatabase access = new AccessToDatabase();
    EntityService ES = new EntityService();
    Serialization S = new Serialization();

    public void MainMenu() throws IOException {
        System.out.println("!!!All your information will be automatically serialized!!!\n1.Get all information\n2.Add city\n3.Add country\n4.Delete city\n" +
                "5.Delete country\n6.Change name of city\n7.Change name of country\n8.Get all cities from country\n8.Get all countries");
        while(true)
        {
            Scanner in = new Scanner(System.in);
            String Number = in.nextLine();
            switch(Number)
            {
                case "1":
                    ES.Out(access);
                    S.Serialize(access);
                    break;
                case "2":
                    ES.addCity(access);
                    S.Serialize(access);
                    break;
                case "3":
                    ES.addCountry(access);
                    S.Serialize(access);
                    break;
                case "4":
                    ES.deleteCity(access);
                    S.Serialize(access);
                    break;
                case "5":
                    ES.deleteCountry(access);
                    S.Serialize(access);
                    break;
                case"6":
                    ES.updateCity(access);
                    S.Serialize(access);
                    break;
                case"7":
                    ES.updateCountry(access);
                    S.Serialize(access);
                    break;
                case "8":
                    ES.AllCitiesWithCode(access);
                    S.Serialize(access);
                    break;
                case"9":
                    ES.AllCountries(access);
                    S.Serialize(access);
                    break;
                case"0":
                    System.exit(0); break;
                default:
                    System.out.println("Choose from 1-9! If you want to exit choose 0");
                    break;


            }
        }
    }
}
