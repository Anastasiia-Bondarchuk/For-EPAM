package BLL;

import DAO.AccessToDatabase;
import DAO.City;
import DAO.Country;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class EntityService {

    private final int id=0;
    public void Out(AccessToDatabase access)
    {
        for (var i:access.getCountries().getAll()) {
            System.out.println(i.getId() +" "+ i.getName());
            int numb =0;
            for (var j:access.AllCitiesWithCode(i.getId())) {
                if(j.getCountryCode()==i.getId())
                {
                    numb++;
                    System.out.println("\t"+numb +". "+ j.getName() +"\n\t\tPopulation: " + j.getPopulation() +"\n\t\tCapital:"+ j.getIsCapital());

                }
            }
        }

    }
    public void addCountry(AccessToDatabase access) {
        Scanner in = new Scanner(System.in);
        System.out.println("Write name of country:");
        String Name = in.nextLine();
        Country MyCountry = new Country(Name, id);
        access.addCountry(MyCountry);
        System.out.println("\n---------------------\n\t\tYour result:");
        Out(access);
    }

    public void addCity(AccessToDatabase access) throws IOException {

        Scanner in = new Scanner(System.in);
        System.out.println("Write name of city:");
        String Name = in.nextLine();
        System.out.println("Write population of city:");
        int Population = in.nextInt();
        System.out.println("Write name of country this city belongs to:");
        Scanner in1 = new Scanner(System.in);
        String CountryCode = in1.nextLine();
        int BelongsToCountry=0;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo(CountryCode)==0)
            {
                BelongsToCountry = i.getId();
            }
        }
        if (BelongsToCountry==0)
        {
            throw new IOException("This country doesn't exist in database!");
        }
        System.out.println("Is this city capital? \nyes(1) no(2)");
        int choose = in1.nextInt();
        String IsCapital=null;
        if(choose==1) {IsCapital = "yes";}
        else if(choose==2) {IsCapital="no";}
        else {
            throw new IOException("Choose 1 or 2!");
        }
        City MyCity = new City(Name, id,Population, IsCapital, BelongsToCountry);
        access.addCity(MyCity);
        System.out.println("\n---------------------\n\t\tYour result:");
        Out(access);

    }

    public void deleteCountry(AccessToDatabase access) throws IOException {

        Scanner myscan = new Scanner(System.in);
        System.out.println("BE CAREFUL! IF YOU DELETE A COUNTRY ALL IT'S CITIES WILL BE ALSO DELETED! \nWrite name of country which you want to delete:");
        String Name = myscan.nextLine();
        Country MyCountry = null;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo(Name)==0)
            {
                MyCountry =i;
            }
        }
        if (MyCountry==null)
        {
            throw new IOException("This country doesn't exist in database!");
        }

       for(var i: new ArrayList<>(access.getAllCities()))
       {
           if(i.getCountryCode()==MyCountry.getId())
           {
               access.deleteCity(i);
           }
       }
        access.deleteCountry(MyCountry);
        System.out.println("\n---------------------\n\t\tYour result:");
        Out(access);

    }

    public void deleteCity(AccessToDatabase access) throws IOException {
        Scanner in = new Scanner(System.in);
        System.out.println("Write name of city which you want to delete:");
        String Name = in.nextLine();
        City MyCity = null;
        for(var i: access.getAllCities())
        {
            if(i.getName().compareTo(Name)==0)
            {
                MyCity =i;
            }
        }
        if (MyCity==null)
        {
            throw new IOException("This city doesn't exist in database!");
        }
        access.deleteCity(MyCity);
        System.out.println("\n---------------------\n\t\tYour result:");
        Out(access);

    }

    public void updateCountry(AccessToDatabase access) throws IOException {
        Scanner in = new Scanner(System.in);
        System.out.println("BE CAREFUL! LIST OF COUNTRIES CAN BE NOT AVAILABLE FOR COUNTRY WITH NEW NAME!\nWrite name of country which you want to update:");
        String Name = in.nextLine();
        Country MyCountry = null;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo(Name)==0)
            {
                MyCountry =i;
            }
        }
        if (MyCountry==null)
        {
            throw new IOException("This country doesn't exist in database!");
        }
        Scanner in1 = new Scanner(System.in);
        System.out.println("Write changed name for this country:");
        String changedName = in1.nextLine();
        access.updateCountry(MyCountry, changedName);
        System.out.println("\n---------------------\n\t\tYour result:");
        Out(access);

    }

    public void updateCity(AccessToDatabase access) throws IOException {

        Scanner in = new Scanner(System.in);
        System.out.println("Write name of city which you want to update:");
        String Name = in.nextLine();
        City MyCity = null;
        for(var i: access.getAllCities())
        {
            if(i.getName().compareTo(Name)==0)
            {
                MyCity =i;
            }
        }
        if (MyCity==null)
        {
            throw new IOException("This city doesn't exist in database!");
        }
        Scanner in1 = new Scanner(System.in);
        System.out.println("Write changed name for this city:");
        String changedName = in1.nextLine();
        access.updateCity(MyCity, changedName);
        System.out.println("\n---------------------\n\t\tYour result:");
        Out(access);

    }

    public void FindCountry(AccessToDatabase access) throws IOException {

        Scanner in = new Scanner(System.in);
        System.out.println("Write name of city which you want to find:");
        String Name = in.nextLine();
        Country MyCountry = access.FindCountry(Name);
        System.out.println(MyCountry.getId() +" "+ MyCountry.getName());

    }

    public void FindCity(AccessToDatabase access) {

        Scanner in = new Scanner(System.in);
        System.out.println("Write name of city which you want to find:");
        String Name = in.nextLine();
        City MyCity = access.FindCity(Name);
        Country newcountry=null;
        for(var i: access.getCountries().getAll())
        {
            if(i.getId()==MyCity.getCountryCode())
            {
                newcountry=i;
            }
        }
        System.out.println(MyCity.getName() + " belongs to "+newcountry.getName()+"\n\t\tPopulation: " + MyCity.getPopulation() +"\n\t\tCapital:"+ MyCity.getIsCapital());
    }

    public void AllCitiesWithCode(AccessToDatabase access) throws IOException {

        Scanner in = new Scanner(System.in);
        System.out.println("Write name of country which you want to get a list of cities in:");
        String Name = in.nextLine();
        Country MyCountry = null;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo(Name)==0)
            {
                MyCountry =i;
            }
        }
        if (MyCountry==null)
        {
            throw new IOException("This country doesn't exist in database!");
        }

        for(var i:access.AllCitiesWithCode(MyCountry.getId()))
        {
            System.out.println(i.getName() +"\n\t\tPopulation: " + i.getPopulation() +"\n\t\tCapital:"+ i.getIsCapital());
        }
    }

    public void AllCountries(AccessToDatabase access) {

        for (var i:access.AllCountries()) {
            System.out.println(i.getId() +" "+ i.getName());
        }

    }
}
