package DAO;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class SerializationTest {

    @Test
    public void SerializeAndDeserialize() {

        AccessToDatabase Access1 = new AccessToDatabase();
        AccessToDatabase Access2 = new AccessToDatabase();
        Serialization S = new Serialization();
        S.Serialize(Access1);
        S.Deserialize();
        Access2 = S.getDeserializedFile();
        assertEquals(Access1.getCountries().getCountry(1).getName(), Access2.getCountries().getCountry(1).getName());
    }

}