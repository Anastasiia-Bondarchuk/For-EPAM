package DAO;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class AccessToDatabaseTest {


    @org.junit.Test
    public void addCountry() {

        AccessToDatabase access = new AccessToDatabase();
        Country MyCountry = new Country("Australia", 0);
        access.addCountry(MyCountry);
        boolean check = false;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo(MyCountry.getName())==0)
                check = true;
        }
        assertEquals( true, check);
        access.deleteCountry(MyCountry);
    }

    @org.junit.Test
    public void addCity() {

        AccessToDatabase access = new AccessToDatabase();
        City MyCity = new City("Krehaiv", 0, 3456782, "No", 2);
        access.addCity(MyCity);
        boolean check = false;
        for(var i: access.getAllCities())
        {
            if(i.getName().compareTo(MyCity.getName())==0)
                check = true;
        }
        assertEquals( true, check);
        access.deleteCity(MyCity);
    }

    @org.junit.Test
    public void deleteCountry() {
        AccessToDatabase access = new AccessToDatabase();
        Country MyCountry = new Country("Australia", 0);
        access.addCountry(MyCountry);
        access.deleteCountry(MyCountry);
        boolean check = false;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo(MyCountry.getName())==0)
                check = true;
        }
        assertEquals( true, !check);

    }

    @org.junit.Test
    public void deleteCity() {
        AccessToDatabase access = new AccessToDatabase();
        City MyCity = new City("Krehaiv", 0, 3456782, "No", 2);
        access.addCity(MyCity);
        access.deleteCity(MyCity);
        boolean check = false;
        for(var i: access.getAllCities())
        {
            if(i.getName().compareTo(MyCity.getName())==0)
                check = true;
        }
        assertEquals( true, !check);
    }

    @org.junit.Test
    public void updateCountry() {

        AccessToDatabase access = new AccessToDatabase();
        Country MyCountry = new Country("TestCountry", 0);
        access.addCountry(MyCountry);
        access.updateCountry(MyCountry, "Test Success");
        boolean check = false;
        for(var i: access.getCountries().getAll())
        {
            if(i.getName().compareTo("Test Success")==0)
                check = true;
        }
        assertEquals( true, check);
        MyCountry.setName("Test Success");
        access.deleteCountry(MyCountry);
    }

    @org.junit.Test
    public void updateCity() {
        AccessToDatabase access = new AccessToDatabase();
        City MyCity = new City("TestCity", 0, 3456782, "No", 2);
        access.addCity(MyCity);
        access.updateCity(MyCity, "Test Success");
        boolean check = false;
        for(var i: access.getAllCities())
        {
            if(i.getName().compareTo("Test Success")==0)
                check = true;
        }
        assertEquals( true, check);
        MyCity.setName("Test Success");
        access.deleteCity(MyCity);
    }

    @org.junit.Test
    public void findCountry() {
        AccessToDatabase access = new AccessToDatabase();
        Country MyCountry = new Country("TestCountry", 0);
        access.addCountry(MyCountry);
        assertEquals( MyCountry, access.FindCountry(MyCountry.getName()));
        access.deleteCountry(MyCountry);
    }

    @org.junit.Test
    public void findCity() {
        AccessToDatabase access = new AccessToDatabase();
        City MyCity = new City("TestCity", 0, 3456782, "No", 2);
        access.addCity(MyCity);
        assertEquals( MyCity, access.FindCity(MyCity.getName()));
        access.deleteCity(MyCity);
    }

    @org.junit.Test
    public void AllCitiesWithCode() {
        AccessToDatabase access = new AccessToDatabase();
        ArrayList<City>MyArray = new ArrayList<City>();
        for (var i:access.getCountries().getAll()) {
            if(i.getId()==2)
            {
                for (var j:access.AllCitiesWithCode(i.getId())) {
                    if(j.getCountryCode()==i.getId())
                    {
                       MyArray.add(j);
                    }

                }
            }

        }
        assertEquals(MyArray,access.AllCitiesWithCode(2));
    }

    @org.junit.Test
    public void allCountries() {
        AccessToDatabase access = new AccessToDatabase();
        ArrayList<Country>MyArray = new ArrayList<Country>();
        for (var i : access.getCountries().getAll()) {
            MyArray.add(i);
        }
        assertEquals(MyArray, access.AllCountries());
    }
}