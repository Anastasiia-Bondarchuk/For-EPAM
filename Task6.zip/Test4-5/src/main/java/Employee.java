import java.math.BigDecimal;

public abstract class Employee {

    private String LastName;
    private BigDecimal salary;
    protected BigDecimal bonus;

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }


    public String getLastName() {
        return LastName;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public Employee(String lastName, BigDecimal salary) {
        LastName = lastName;
        this.salary = salary;
    }

    public abstract BigDecimal setBonus();

}
