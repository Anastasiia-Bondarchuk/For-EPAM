import java.math.BigDecimal;

public class Company {
    private Employee []employee;

    public Company(Employee[] employee) {
        this.employee = employee;
    }

    public void giveEverybodyBonus ()
    {
        for (var item: employee)
            item.setBonus();

    }

    public BigDecimal totalToPay()
    {
        BigDecimal sum = BigDecimal.valueOf(0);
        for (var item: employee)
        {
            sum = sum.add(item.getSalary());
        }
        return sum;
    }

    public String nameMaxSalary()
    {
        BigDecimal max = BigDecimal.valueOf(0);
        for (var item: employee)
        {
            item.setSalary(item.setBonus());
            if(max.compareTo(item.getSalary())==-1)
            {
                max = item.getSalary();
            }
        }
        for (var item: employee)
        {
            if(item.getSalary().compareTo(max)==0)
            {
                return item.getLastName();
            }
        }
        return "Can`t get information";
    }

}
