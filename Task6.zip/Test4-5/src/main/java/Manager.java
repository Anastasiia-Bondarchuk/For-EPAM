import java.math.BigDecimal;

public class Manager extends Employee{

    private int quantity;
    public Manager(String lastName, BigDecimal salary, int ClientAmount) {
        super(lastName, salary);
        quantity = ClientAmount;
    }

    @Override
    public BigDecimal setBonus() {
        if (quantity>=100 && quantity<150) bonus = BigDecimal.valueOf(500).add(getSalary());
        else if(quantity>=150) bonus = BigDecimal.valueOf(1000).add(getSalary());
        else bonus = getSalary();
        setSalary(bonus);
        return getSalary();
    }
}
