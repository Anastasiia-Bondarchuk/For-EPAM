import java.math.BigDecimal;

public class SalesPerson extends Employee {

    private double percent;
    public SalesPerson(String lastName, BigDecimal salary, double Percent) {
        super(lastName, salary);
        percent = Percent;
    }

    @Override
    public BigDecimal setBonus() {

        if (percent>=100 && percent<200) bonus = BigDecimal.valueOf(2).multiply(getSalary());
        else if(percent>=200) bonus = BigDecimal.valueOf(3).multiply(getSalary());
        else bonus = getSalary();
        setSalary(bonus);
        return getSalary();
    }
}
