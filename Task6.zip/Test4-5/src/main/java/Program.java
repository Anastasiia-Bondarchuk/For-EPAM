import java.math.BigDecimal;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {

        Employee []All;
        All = new Employee[]{
                new SalesPerson( "Andriy", BigDecimal.valueOf(1200.56), 130),
                new Manager("Anton", BigDecimal.valueOf(2600.56), 150),
                new SalesPerson("Mykola", BigDecimal.valueOf(1200.56), 200),
                new Manager("Bohdan", BigDecimal.valueOf(2600.56), 100)};
        Company comp = new Company(All);

        for (var item: All) {

            System.out.println("Name:" + item.getLastName() + "\nStatic salary:" + item.getSalary() + "\n");

        }

        comp.giveEverybodyBonus();
        System.out.println("\nAfter bonus: \n");
        for (var item: All) {

            System.out.println("Name:" + item.getLastName() + "\nSalary:" + item.getSalary() + "\n");

        }

        System.out.println("\nAmount of salary: " + comp.totalToPay());
        System.out.println("\nTe biggest salary has: " + comp.nameMaxSalary());

    }

}
