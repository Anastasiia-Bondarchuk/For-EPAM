import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class CompanyTest {

    @Test
    void giveEverybodyBonus() {
        Employee []All;
        All = new Employee[]{
                new SalesPerson( "Andriy", BigDecimal.valueOf(1200), 130)};
        Company comp = new Company(All);
        comp.giveEverybodyBonus();
        assertEquals(BigDecimal.valueOf(2400), All[0].getSalary());
    }

    @Test
    void totalToPay() {
        Employee []All;
        All = new Employee[]{
                new SalesPerson( "Andriy", BigDecimal.valueOf(1200), 130),
                new Manager("Anton", BigDecimal.valueOf(2600), 150)};
        Company comp = new Company(All);
        assertEquals(BigDecimal.valueOf(2400+3600), comp.totalToPay());
    }

    @Test
    void nameMaxSalary() {
        Employee []All;
        All = new Employee[]{
                new SalesPerson( "Andriy", BigDecimal.valueOf(1200.56), 130),
                new Manager("Anton", BigDecimal.valueOf(2600.56), 150),
                new SalesPerson("Mykola", BigDecimal.valueOf(1200.56), 200),
                new Manager("Bohdan", BigDecimal.valueOf(2600.56), 100)};
        Company comp = new Company(All);
        assertEquals("Mykola", comp.nameMaxSalary());
    }
}