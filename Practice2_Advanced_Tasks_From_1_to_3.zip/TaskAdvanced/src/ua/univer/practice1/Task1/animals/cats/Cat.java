package ua.univer.practice1.Task1.animals.cats;

public class Cat {

    private String name;

    Cat(){};
    public Cat(String _name) {
        name = _name;
    }
}
