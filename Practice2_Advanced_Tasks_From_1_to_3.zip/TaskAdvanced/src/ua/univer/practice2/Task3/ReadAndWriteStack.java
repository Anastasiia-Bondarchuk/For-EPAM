package ua.univer.practice2.Task3;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ua.univer.practice2.Task1.CITY;
import ua.univer.practice2.Task2.QueueImpl;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class ReadAndWriteStack {

    ArrayList<CITY> cities = new ArrayList<>();
    String path = "C:\\Users\\Настя\\Desktop\\Cities.xml";
    String line="";

    public void read(StackImpl<CITY> stackimpl)
    {
        try{
            BufferedReader br = new BufferedReader(new FileReader(path));
            while((line = br.readLine()) != null)
            {
                stackimpl.push(new CITY(line));
            }
        }catch(FileNotFoundException e)
        {
            e.printStackTrace();
        }catch(IOException e)
        {
            e.printStackTrace();
        }

    }

    public String write(StackImpl<CITY> stackimpl) throws JsonProcessingException {
        cities.clear();
        ObjectMapper objectMapper = new ObjectMapper();
        for(Object i: stackimpl)
        {
            cities.add((CITY)i);
        }
        String result = objectMapper.writeValueAsString(cities);
        return result;
    }
}
