import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BaseDepositTest {

    @Test
    void income() {
        BaseDeposit baseDeposit = new BaseDeposit(2300.9, 9);
        assertEquals(1268.5510921449686,baseDeposit.income());
    }
}