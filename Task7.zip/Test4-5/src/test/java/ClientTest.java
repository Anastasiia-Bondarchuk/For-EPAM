import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {

    @Test
    void addDeposit() {
        Client client = new Client();
        assertEquals( false ,client.addDeposit(new LongDeposit(34, 5)));
    }

    @Test
    void totalIncome() {
        Client client = new Client();
        assertEquals( 7993.750720203136,client.totalIncome());
    }

    @Test
    void maxIncome() {
        Client client = new Client();
        assertEquals( 3665.639666667139,client.maxIncome());
    }

    @Test
    void getIncomeByNumber() {
        Client client = new Client();
        assertEquals( 1096.499999999999,client.getIncomeByNumber(3));
    }
}