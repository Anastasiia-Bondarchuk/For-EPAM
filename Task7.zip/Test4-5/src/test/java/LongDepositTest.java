import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LongDepositTest {

    @Test
    void income() {
        LongDeposit longDeposit = new LongDeposit(2300.9, 9);
        assertEquals(1198.4812874999993,longDeposit.income());
    }
}