import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SpecialDepositTest {

    @Test
    void income() {
        SpecialDeposit specialDeposit = new SpecialDeposit(2300, 9);
        specialDeposit.income();
        assertEquals(1258.353915423047,specialDeposit.income());
    }
}