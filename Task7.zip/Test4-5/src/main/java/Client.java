public class Client {

    public Deposit[] depositArr;
    private int index;

    public Client() {
        depositArr = new Deposit[]{new LongDeposit(4500, 8), new SpecialDeposit(6700, 9), new LongDeposit(3400, 8), new SpecialDeposit(7800, 6)};
        index = 4;
    }

    public boolean addDeposit(Deposit _deposit)
    {
        if(index>=4)
        {
            return false;
        }
        depositArr[index++] = _deposit;
        return true;
    }
    public double totalIncome()
    {
        double total = 0.0;
        for(int i=0; i<index;i++)
        {
            total += depositArr[i].income();
        }
        return total;
    }
    public double maxIncome()
    {
        double max=0;
        for (int i=0;i<index;i++)
        {
            if(depositArr[i].income()>max)
            {
                max = depositArr[i].income();
            }
        }
        return max;
    }
    public double getIncomeByNumber(int number)
    {
        number--;
        if(number<=0 || number > index)
        {
            return 0;
        }
        return depositArr[number].income();
    }
}
