public class LongDeposit extends Deposit {
    public LongDeposit(double _amount, int _period) {
        super(_amount, _period);
    }

    @Override
    double income() {
        double result = amount();
        for(int i=0;i<period()-6;i++)
        {
            result *=1.15;
        }
        return result - amount();
    }
}
