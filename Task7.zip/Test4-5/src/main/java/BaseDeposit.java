public class BaseDeposit extends Deposit{

    public BaseDeposit(double _amount, int _period) {
        super(_amount, _period);
    }

    @Override
    double income() {
        double result = amount();
        for(int i=0;i<period();i++)
        {
            result *=1.05;
        }
        return result - amount();
    }
}
