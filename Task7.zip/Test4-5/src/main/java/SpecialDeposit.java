import java.math.BigDecimal;

public class SpecialDeposit extends Deposit{
    public SpecialDeposit(double _amount, int _period) {
        super(_amount, _period);
    }

    @Override
    public double income() {
        double result = amount();
        double small =0;
        for (int i =1; i<= period(); i++)
        {
            small = (double)i/100;
            result = result + result * small;
        }
        return result - amount();
    }
}
