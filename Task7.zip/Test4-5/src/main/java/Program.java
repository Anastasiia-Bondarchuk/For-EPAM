import java.math.BigDecimal;
import java.util.Scanner;

public class Program {

    public static void main(String[] args) {



    }

}
