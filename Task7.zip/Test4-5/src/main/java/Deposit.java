import java.math.BigDecimal;

public abstract class Deposit {

    private double amount;
    private int period;

    protected double amount()
    {
        return amount;
    }
    protected void setAmount(double _amount)
    {
        amount = _amount;
    }
    protected int period()
    {
        return period;
    }
    protected Deposit(double _amount, int _period)
    {
        amount = _amount;
        period = _period;
    }
    abstract double income();
}
