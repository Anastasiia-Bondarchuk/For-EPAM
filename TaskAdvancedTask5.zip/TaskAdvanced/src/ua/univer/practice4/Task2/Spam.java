package ua.univer.practice4.Task2;

import com.fasterxml.jackson.databind.util.TokenBufferReadContext;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class Spam {

    private static class Worker extends Thread {
        String[] messages;
        int[] times;
        private Spam.InputData inputData= new InputData();

        public Worker(String[] messages, int[] times) {
            this.messages = messages;
            this.times = times;
        }

        @Override
        public void run() {

            inputData = new InputData();
            try {
                inputData.read();
            } catch (IOException e) {
                e.printStackTrace();
            }

            for (int i = 0; i < messages.length; i++) {
                System.out.print(messages[i] + " ");
                try {
                    Thread.sleep(times[i]);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }

    private Spam.Worker worker;

    public Spam() {
        String[] messages = new String[]{"@@@", "bbbbbbb", "qwq", "wow"};
        int[] times = new int[]{1000, 1000, 1000, 1000};
        worker = new Worker(messages, times);
    }

    private static class InputData extends InputStream {

        String enter;

        public InputData() {
            enter = "";
        }

        @Override
        public int read() throws IOException {

            Scanner scanner = new Scanner(System.in);
            enter =scanner.nextLine();
            return 0;
        }

    }

    static class MyThread implements Runnable {
        Spam sp = new Spam();
        @Override
        public void run() {
            if(sp.worker.inputData.enter==" ") {
                try {
                    sp.worker.wait(6000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args)
    {
        Spam sp = new Spam();
        sp.worker.start();
        Thread th = new Thread(new MyThread());
        th.start();

    }
}
