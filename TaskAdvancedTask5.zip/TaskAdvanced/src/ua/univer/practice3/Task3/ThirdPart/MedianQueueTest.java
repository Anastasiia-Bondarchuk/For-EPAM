package ua.univer.practice3.Task3.ThirdPart;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MedianQueueTest {

    @Test
    void size() {

        MedianQueue my = new MedianQueue();

        my.offer(4);
        my.offer(5);
        my.offer(2);

        assertEquals(3, my.size());
    }

    @Test
    void offer() {

        MedianQueue my = new MedianQueue();

        my.offer(4);
        my.offer(5);
        my.offer(2);

        assertEquals(true, my.contains(5));
    }

    @Test
    void contains() {
        MedianQueue my = new MedianQueue();

        my.offer(4);
        my.offer(5);
        my.offer(2);

        assertEquals(true, my.contains(5));
    }

    @Test
    void poll() {
        MedianQueue my = new MedianQueue();

        my.offer(4);
        my.offer(5);
        my.offer(2);
        my.poll();

        assertEquals(false, my.contains(4));
    }

    @Test
    void median() {

        MedianQueue my = new MedianQueue();

        my.offer(4);
        my.offer(5);
        my.offer(2);

        assertEquals(5,  my.median());
    }

    @Test
    void peek() {

        MedianQueue my = new MedianQueue();

        my.offer(4);
        my.offer(5);
        my.offer(2);

        assertEquals(4,  my.peek());
    }
}