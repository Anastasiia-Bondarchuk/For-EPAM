package ua.univer.practice3.Task3.SecondPart;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Consumer;

public class SortedByAbsoluteValue implements Iterable {

    static class Node {
        Integer element;
        Node next;
        Node prev;

        public Node(Integer element) {
            this.element = element;
        }

        @Override
        public String toString() {
            return "" + element + ' ';
        }
    }

    Node root;

    public int size()
    {
        return size(root);
    }

    private int size(Node current) {
        int size =0;
        if(current==null)
            return 0;
        else size = 1+size(current.prev)+size(current.next);
        return size;
    }

    public boolean add(Integer element) {
        Node current = new Node(element);
        if (root == null) {
            root = current;
            return true;
        } else {
            return insert(root, element);
        }
    }

    private boolean insert(Node current, Integer element) {
        if (element.compareTo(current.element) < 0) {
            if (current.prev == null) {
                current.prev = new Node(element);
                return true;
            } else {
                return insert(current.prev, element);
            }
        } else if (element.compareTo(current.element) > 0) {
            if (current.next == null) {
                current.next = new Node(element);
                return true;
            } else {
                return insert(current.next, element);
            }
        } else return false;
    }

    public boolean contains(Integer value) {
        return contains(root, value);
    }

    private boolean contains(Node current, Integer element)
    {
        if(current==null)
        {
            return false;
        }else if(element.compareTo(current.element)<0)
        {
            return contains(current.prev, element);
        }else if(element.compareTo(current.element)>0)
        {
            return contains(current.next, element);
        }else return true;
    }

    public void addCollection(SortedByAbsoluteValue collection)
    {
        addCollection(collection, collection.root);
    }

    private void addCollection(SortedByAbsoluteValue collection, Node current) {

        if(current==collection.root)
        {
            add(current.element);
        }
        if(current.prev != null) {
            add(current.prev.element);
            addCollection(collection, current.prev);
        }
        if(current.next != null) {
            add(current.next.element);
            addCollection(collection, current.next);
        }
    }

    public void inOrderTraversal()
    {
        inOrderTraversal(root);
    }

    private void inOrderTraversal(Node current)
    {
        if(current==null)
            return;

        inOrderTraversal(current.prev);
        System.out.print(current.element+ " ");
        inOrderTraversal(current.next);
    }

    public boolean delete(int value)
    {
        return delete(root, value)!=null?true : false;
    }

    private Node delete(Node current, int value)
    {
        if(current==null)
        {
            return current;
        }else if(current.element.compareTo(value)>0)
            current.prev=delete(current.prev, value);
        else if(current.element.compareTo(value)<0)
            current.next=delete(current.next, value);
        else {

            if(current.prev ==null && current.next==null)
            {
                current=null;
                return current;
            }else if(current.prev==null)
            {
                current=current.next;
                return current;
            }else if(current.next==null)
            {
                current=current.prev;
                return current;
            }
        }
        return current;
    }

    @Override
    public String toString() {
        String result = "";
        Node current = root;
        while (current.next != null) {
            result += current.element;
            current = current.next;
        }
        result = result + current.element;
        return "" + result+" ";
    }

    public Iterator<Integer> iterator() {
        Node firstNode = root;
        return new Iterator<Integer>() {
            Node currentNode = null;

            @Override
            public boolean hasNext() {
                if (firstNode == null) {
                    return false;
                } else if (currentNode == null) {
                    return true;
                } else if (currentNode.next == null) {
                    return false;
                }
                return true;
            }

            @Override
            public Integer next() {
                if (firstNode == null) {
                    throw new NoSuchElementException();
                } else if (currentNode == null) {
                    this.currentNode = firstNode;
                    return currentNode.element;
                } else if (currentNode.next == null) {
                    throw new NoSuchElementException();
                }
                this.currentNode = currentNode.next;
                return currentNode.element;
            }
        };
    }
}
