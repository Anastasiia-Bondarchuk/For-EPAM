package ua.univer.practice3.Task1;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RangedOpsIntegerSetTest {

    @Test
    void size() {
        RangedOpsIntegerSet rois = new RangedOpsIntegerSet();
        rois.add(1, 5);
        assertEquals(4, rois.size());
    }


    @Test
    void add() {
        RangedOpsIntegerSet rois = new RangedOpsIntegerSet();
        rois.add(2);
        List<Integer> list = new ArrayList<>();
        for(int i: rois)
        {
            list.add(i);
        }
        assertEquals(true, list.contains(2));
    }

    @Test
    void remove() {
        RangedOpsIntegerSet rois = new RangedOpsIntegerSet();
        rois.add(1, 15);
        rois.remove(6);
        List<Integer> list = new ArrayList<>();
        for(int i: rois)
        {
            list.add(i);
        }
        assertEquals(false, list.contains(6));
    }


    @Test
    void testAdd() {
        RangedOpsIntegerSet rois = new RangedOpsIntegerSet();
        rois.add(1, 5);
        List<Integer> list = new ArrayList<>();
        for(int i: rois)
        {
            list.add(i);
        }
        assertEquals(true, list.contains(4));
    }

    @Test
    void testRemove() {
        RangedOpsIntegerSet rois = new RangedOpsIntegerSet();
        rois.add(1, 15);
        rois.remove(3,12);
        List<Integer> list = new ArrayList<>();
        for(int i: rois)
        {
            list.add(i);
        }
        assertEquals(false, list.contains(6));
    }
}