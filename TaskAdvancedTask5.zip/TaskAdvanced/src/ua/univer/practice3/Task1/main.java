package ua.univer.practice3.Task1;

import ua.univer.practice3.Task1.RangedOpsIntegerSet;

public class main {

    public static void main(String [] args) throws Exception {

        RangedOpsIntegerSet rois = new RangedOpsIntegerSet();
        rois.add(1, 5);
        rois.add(9,11);
        for(var el : rois)
        {
            System.out.print(el + " ");
        }
        System.out.println();
        RangedOpsIntegerSet set = new RangedOpsIntegerSet();
        set.add(1, 15);
        for(Integer el : set){
            System.out.print(el + " ");
        }
        System.out.println();
        set.remove(5, 12);
        for(Integer el : set){
            System.out.print(el + " ");
        }


    }
}
