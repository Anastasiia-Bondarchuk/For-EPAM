package ua.univer.practice1.Task1.house;

import org.junit.jupiter.api.Test;
import ua.univer.practice1.Task1.animals.cats.Cat;
import ua.univer.practice1.Task1.animals.cats.Kitten;
import ua.univer.practice1.Task1.animals.dogs.Dog;
import ua.univer.practice1.Task1.animals.dogs.Puppy;

import static org.junit.jupiter.api.Assertions.*;

class HouseTest {

    @Test
    void enter() {

        Dog spike = new Dog("Spike");
        Puppy rex = new Puppy("Rex");
        Cat bohdan = new Cat("Bohdan");
        Kitten phill = new Kitten("Phill");

        House<Dog> dogHouse = new House<>();
        dogHouse.enter(spike);
        dogHouse.enter(rex);
        assertEquals(dogHouse.animals.contains(spike), true);
        assertEquals(dogHouse.animals.contains(rex), true);
        House<Cat> catHouse = new House<>();
        catHouse.enter(phill);
        catHouse.enter(bohdan);
        assertEquals(catHouse.animals.contains(phill), true);
        assertEquals(catHouse.animals.contains(bohdan), true);

    }
}