package ua.univer.practice1.Task1.animals.dogs;

public class Dog {

    private String name;

    public String getName() {
        return name;
    }

   public Dog(){};
   public Dog(String _name) {
        name = _name;
    }

}
