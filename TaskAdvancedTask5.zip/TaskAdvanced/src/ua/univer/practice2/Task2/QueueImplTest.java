package ua.univer.practice2.Task2;

import org.junit.jupiter.api.Test;
import ua.univer.practice2.Task1.CITY;

import static org.junit.jupiter.api.Assertions.*;

class QueueImplTest {

    @Test
    void clear() {
        QueueImpl<CITY> cities= new QueueImpl<>();
        ReadAndWriteQueue rawq = new ReadAndWriteQueue();
        rawq.read(cities);
        cities.clear();
        assertEquals(null, cities.getByIndex(0));
    }

    @Test
    void size() {
        QueueImpl<CITY> cities= new QueueImpl<>();
        ReadAndWriteQueue rawq = new ReadAndWriteQueue();
        rawq.read(cities);
        assertEquals(7, cities.size());
    }

    @Test
    void enqueue() {
        QueueImpl<CITY> cities= new QueueImpl<>();
        ReadAndWriteQueue rawq = new ReadAndWriteQueue();
        rawq.read(cities);
        cities.enqueue(new CITY("City"));
        assertEquals("City", cities.getByIndex(7).getCity().toString());
    }

    @Test
    void dequeue() {
        QueueImpl<CITY> cities= new QueueImpl<>();
        ReadAndWriteQueue rawq = new ReadAndWriteQueue();
        rawq.read(cities);
        cities.dequeue();
        assertEquals("Kharkiv", cities.getByIndex(0).getCity().toString());
    }

    @Test
    void top() {
        QueueImpl<CITY> cities= new QueueImpl<>();
        ReadAndWriteQueue rawq = new ReadAndWriteQueue();
        rawq.read(cities);
        assertEquals("Kyiv", cities.top().getCity().toString());
    }
}