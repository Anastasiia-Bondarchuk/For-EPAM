package ua.univer.practice2.Task1;

public class CITY {

    public String getCity() {
        return city;
    }

    public CITY(String city) {
        this.city = city;
    }

    public String city;
}
