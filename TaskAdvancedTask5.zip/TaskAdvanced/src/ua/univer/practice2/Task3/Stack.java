package ua.univer.practice2.Task3;

import ua.univer.practice1.Task2.Container;

public interface Stack<T> extends Container {

    // Pushes the specified element onto the top.
    void push(T element);

    // Removes and returns the top element.
    T pop();

    // Returns the top element.
    T top();
}
