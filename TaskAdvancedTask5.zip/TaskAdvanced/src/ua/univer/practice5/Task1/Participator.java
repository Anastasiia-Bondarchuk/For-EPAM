package ua.univer.practice5.Task1;

public class Participator {

    private int request;
    private String id;
    boolean isPaid =true;

    public String getId() {
        return id;
    }

    public boolean isPaid() {
        return isPaid;
    }

    public void setPaid(boolean paid) {
        isPaid = paid;
    }

    public Participator(int randomRequest) {
        request=randomRequest;
        id="id";
        for(int i=0;i<10;i++)
        {
            id+=(int)(Math.random()*10);
        }
    }

    public Participator() {
        request=0;
        id="id";
    }

    public int getRequest() {
        return request;
    }

    public void setRequest(int request) {
        this.request = request;
    }


}
