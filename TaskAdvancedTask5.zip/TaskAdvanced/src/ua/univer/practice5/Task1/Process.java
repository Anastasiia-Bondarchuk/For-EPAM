package ua.univer.practice5.Task1;

import ua.univer.practice5.Task1.Lot;
import ua.univer.practice5.Task1.Participator;

public class Process implements Runnable{

    private final int count;
    private Lot[]lot;
    private Participator winner;

    public Process(int amountOfLots) {
        count=amountOfLots;
        lot = new Lot[count];
    }


    @Override
    public void run() {
        Thread.currentThread().setName("Tread " + (int)(Math.random()*10));
        for (int i = 0; i < lot.length; i++) {
            if(i==0)
            {
                lot[i]= new Lot();
                winner=lot[i].findWinner();
            }else
            {
                lot[i]= new Lot();
                lot[i].addParticipators(lot[i-1].getParticipators());
                winner=lot[i].findWinner();
            }
            System.out.println("Winner: "+(i+1)+" " + winner.getId() + "\nMoney: "
                    +winner.getRequest()+"\nStart cost:"+lot[i].getStartValue()+"\nPayment: "+
                    winner.isPaid()+"\nName of thread: "+ Thread.currentThread().getName()+"\n");
        }

    }
}
