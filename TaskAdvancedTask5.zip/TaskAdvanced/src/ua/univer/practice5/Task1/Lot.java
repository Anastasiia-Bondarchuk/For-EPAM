package ua.univer.practice5.Task1;


import java.util.*;

public class Lot {

    private List<Participator> participators;
    private int startValue;
    private final int max=10000000;
    private Participator winner;

    public int getStartValue() {
        return startValue;
    }

    public Participator getWinner() {
        return winner;
    }

    public List<Participator> getParticipators() {
        return participators;
    }

    public Lot() {
        participators = new ArrayList<>();
        startValue=(int)(Math.random()*4000000);
    }

    private int getRandomRequest()
    {
        return startValue+(int)(Math.random()*(max-startValue));
    }

    public synchronized void addParticipators(List<Participator> array)
    {
        for(Participator p: array)
        {
            if(p.isPaid())
            {
                participators.add(p);
                notify();
            }else{
                try {
                    wait(1000);
                    p.setPaid(true);
                    participators.add(p);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }
    }
    public synchronized Participator findWinner()
    {
        if(participators.isEmpty())
        {
            int end =20;
            int finish = (int)(Math.random()*end);
            for (int i = 0; i < finish; i++) {
                participators.add(new Participator(getRandomRequest()));
            }
        }
        winner= new Participator();
        for (int i = 0; i < participators.size(); i++) {
            if(participators.get(i).getRequest()>winner.getRequest())
                winner=participators.get(i);
        }
        Random random = new Random();
        winner.setPaid(random.nextBoolean());
        notify();
        try {
            wait(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return winner;

    }
}
