package ua.univer.practice5.Task3;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class main {

    public static void main(String[] args) {
        Airport airport = new Airport();
        PlanesGenerator planesGenerator = new PlanesGenerator(airport, 20);


        Passengers passengers = new Passengers(airport, 100);
        Passengers passengers2 = new Passengers(airport, 200);
        Passengers passengers3 = new Passengers(airport, 300);

        ExecutorService service = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        service.execute(planesGenerator);
        service.execute(passengers);
        service.execute(passengers2);
        service.execute(passengers3);

        service.shutdown();

    }
}
