package ua.univer.practice5.Task3;

public class PlanesGenerator implements Runnable{

    private Airport airport;
    private int planeCount;

    public PlanesGenerator(Airport airport, int planeCount) {
        this.airport = airport;
        this.planeCount = planeCount;
    }

    private int getRandomType()
    {
        final int []distance = new int[]{800,2000,5000};
        int rand = (int)(Math.random()*distance.length);
        return distance[rand];
    }

    private int getRandomSize()
    {
        final int []sits = new int[]{100,200,300};
        int rand = (int)(Math.random()*sits.length);
        return sits[rand];
    }

    @Override
    public void run() {

        int count=0;
        int countForMinus=0;
        while(count<planeCount)
        {
            if(countForMinus==airport.getLadders())
            {
                int random = getRandomType();
                Thread.currentThread().setName("\nPlanes are departing: " + random);
                countForMinus--;
                airport.get(random);

            }else {
                Thread.currentThread().setName("\nPlanes are arriving");
                count++;
                countForMinus++;
                airport.add(new Plane(getRandomSize(),getRandomType()));
            }

        }
    }
}
