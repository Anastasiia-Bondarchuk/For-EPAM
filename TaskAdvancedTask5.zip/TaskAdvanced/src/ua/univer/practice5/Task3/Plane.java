package ua.univer.practice5.Task3;

public class Plane {

    private int count;
    private int size;
    private int type;

    public Plane(int size, int type) {
        this.size = size;
        this.type = type;
    }

    public void add(int _count)
    {
        count+=count;
    }
    public boolean countCheck()
    {
        if(count>=size)
        {
            return false;
        }
        return true;
    }

    public int getCount() {
        return count;
    }

    public int getSize() {
        return size;
    }

    public int getType() {
        return type;
    }
}
