package ua.univer.practice5.Task3;

import java.util.ArrayList;
import java.util.List;

public class Airport {

    private List<Plane> planes;
    private final int ladders =6;
    private final int minPlanes =0;
    private int planesCounter=0;

    public int getLadders() {
        return ladders;
    }

    public Airport() {
        planes = new ArrayList();
    }

    public synchronized boolean add(Plane plane)
    {
        try{
            if(planesCounter< ladders)
            {
                notifyAll();
                planes.add(plane);
                System.out.println("The plane arrives: \nAmount of planes: "+ planes.size() +"\nType: "+
                        plane.getType()+"\nSize: "+plane.getSize()+"\n"+Thread.currentThread().getName()+"\n\n");
                planesCounter++;
            }else {
                System.out.println(planes.size()+"\nAll ladders are occupied"+Thread.currentThread().getName());
                wait();
                return false;
            }
        } catch(InterruptedException e)
        {
            e.printStackTrace();
        }
        return true;
    }

    public Plane getPlane(int _type)
    {
        Plane current=null;
        for(Plane plane: planes)
        {
            if(plane.getType()==_type)
                current= plane;
        }
        if(current==null)
            return null;
        else return current;
    }

    public synchronized Plane get(int _type)
    {
        try {
            if(planesCounter>minPlanes)
            {
                notifyAll();
                for(Plane plane: planes)
                {
                    if(plane.getType()==_type)
                    {
                        planesCounter--;
                        System.out.println("Plane is departed from the airport: "+Thread.currentThread().getName()+"\n");
                        planes.remove(plane);
                        return plane;
                    }

                }
            }
            System.out.println("\nThere are no planes in airport:");
            wait(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

}
