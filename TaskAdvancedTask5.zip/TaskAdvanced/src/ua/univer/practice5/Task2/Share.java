package ua.univer.practice5.Task2;

public class Share {

    private int amountOfSales;
    private int cost;
    private double percentage;
    private final int min=1000;
    private final int max=10000;

    @Override
    public String toString() {
        return "Share: \n"+"Amount of sales: "+amountOfSales+"\nCost: "+cost+"\n Percentage: "+percentage+"\n";
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public Share(int amountOfSales) {
        this.amountOfSales = amountOfSales;
        cost = min + (int)(Math.random()*(max-min));
        percentage=100;
    }

    public int getAmountOfSales() {
        return amountOfSales;
    }

    public int getCost() {
        return cost;
    }

    public void setAmountOfSales(int amountOfSales) {
        this.amountOfSales = amountOfSales;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
}
