package ua.univer.practice5.Task2;

import java.util.ArrayList;
import java.util.List;

public class Firm {

    private List<Share> shares = new ArrayList<>();
    private double percentage;

    @Override
    public String toString() {
        String firm="Firm: \n";
        for (Share share:shares) {
            firm+=share;
        }
        return firm;
    }

    public Firm() {
        int amountOfActions=3;
        for (int i = 0; i < amountOfActions; i++) {
            shares.add(new Share(0));
        }
        percentage=0;
        for(Share share : shares)
        {
            percentage+=share.getPercentage();
        }
        percentage/=amountOfActions;
    }

    public double getPercentage() {

        percentage=0;
        for(Share share : shares)
        {
            percentage+=share.getPercentage();
        }
        percentage/=shares.size();
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public List<Share> getShares() {
        return shares;
    }
}
