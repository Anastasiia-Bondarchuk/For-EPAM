package ua.univer.practice5.Task2;

import java.util.ArrayList;
import java.util.List;

public class StockExchanges{

    private List<Firm> firms;
    private boolean stop = false;
    private double index;

    public boolean isStop() {
        return stop;
    }

    public void setStop(boolean stop) {
        this.stop = stop;
    }

    public double getIndex() {
        return index;
    }

    public void setIndex(double index) {
        this.index = index;
    }

    @Override
    public String toString() {

        String stock="";
        for (Firm firm:firms) {
            stock+=firm;
        }
        return stock;
    }

    public StockExchanges() {
        firms = new ArrayList<>();
        firms.add(new Firm());
        firms.add(new Firm());
        firms.add(new Firm());

        index=0;

        for (Firm firm: firms) {

            index+=firm.getPercentage();
        }
        index/=firms.size();
    }

    public List<Firm> getFirms() {
        return firms;
    }

    public void setFirms(List<Firm> firms) {
        this.firms = firms;
    }

}
