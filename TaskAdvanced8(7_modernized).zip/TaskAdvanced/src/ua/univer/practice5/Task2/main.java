package ua.univer.practice5.Task2;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class main {

    public static void main(String[] args) {

        StockExchanges se = new StockExchanges();
        Thread process = new Thread(new CountingShares(se));
        Thread process2 = new Thread(new CountingShares(se));
        process.start();
        process2.start();
        try {
            process.join();
            process2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
