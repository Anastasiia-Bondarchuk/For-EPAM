package ua.univer.practice2.Task2;

import com.fasterxml.jackson.core.JsonProcessingException;
import ua.univer.practice2.Task1.CITY;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class QueueImpl<T> implements Queue<T> {

    static class Node<T> {
        T element;
        Node<T> next;

        public Node(T element) {
            this.element = element;
        }
    }

    private Node<T> first;
    private Node<T> last;
    private int size;

    @Override
    public void clear() {
        if(first==null && last==null)
            throw new NoSuchElementException("Your queue is already empty!");
        else{
            first=last=null;
            this.size=0;
        }

    }

    @Override
    public int size() {
        size = 0;
        Node<T> current = first;
        while (current != null) {
            size++;
            current = current.next;

        }
        return size;
    }

    @Override
    public Iterator <T>iterator() {
        final QueueImpl<T> list = this;
        return new Iterator<T>() {

            final Node<T> first = list.first;
            Node<T> current = null;

            @Override
            public boolean hasNext() {

                if (list.first == null)
                    return false;
                else if (current == null)
                    return true;
                else if (current == list.last)
                    return false;
                return true;
            }

            @Override
            public T next() {
                if (list.first == null) throw new NoSuchElementException();
                else if (current == null) {
                    this.current = first;
                    return current.element;
                } else if (current.next == null)
                    throw new NoSuchElementException();
                this.current = current.next;
                return current.element;
            }
        };
    }


    @Override
    public void enqueue(T element) {
        Node<T> current = new Node<T>(element);
        current.element=element;
        if(first==null && last==null)
        {
            first = last = current;
        }
        else{
            last.next=current;
            last=current;
        }
    }

    @Override
    public T dequeue() {

        if(first==null)
        {
            throw new RuntimeException("Queue underflow!");
        }
        else if(first==last)
        {
            T _element = first.element;
            first=last=null;
            return _element;
        }else{
            T _element= first.element;
            first=first.next;
            return _element;
        }
    }

    @Override
    public T top() {
        return first.element;
    }

    public T getByIndex(int index)
    {
        Node<T> current = first;
        int count = 0;
        while (current != null) {
            if (count == index)
                return current.element;
            count++;
            current = current.next;
        }
        return null;
    }

    public void main() throws JsonProcessingException {
        QueueImpl<CITY> cities= new QueueImpl<>();
        ReadAndWriteQueue rawq = new ReadAndWriteQueue();
        rawq.read(cities);
        System.out.println(rawq.write(cities));
        cities.dequeue();
        System.out.println(rawq.write(cities));
        cities.clear();
        cities.enqueue(new CITY("Tokyo"));
        System.out.println(rawq.write(cities));
        System.out.println(cities.top().getCity().toString());
    }
}
