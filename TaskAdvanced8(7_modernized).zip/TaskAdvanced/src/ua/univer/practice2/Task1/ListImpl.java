package ua.univer.practice2.Task1;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class ListImpl<T> implements List<T> {

    static class Node<T> {
        T element;
        Node<T> next;

        public Node(T element) {
            this.element = element;
        }
    }

    private Node<T> first;
    private Node<T> last;
    private int size;

    @Override
    public void clear() {
        first = last = null;
        this.size = 0;
    }

    @Override
    public int size() {
        size = 0;
        Node<T> current = first;
        while (current != null) {
            size++;
            current = current.next;

        }
        return size;
    }

    public Node<T> getNodeByIndex(int index) {
        Node<T> current = first;
        int count = 0;
        while (current != null) {
            if (count == index)
                return current;
            count++;
            current = current.next;
        }
        return null;
    }

    @Override
    public Iterator<T> iterator() {

        final ListImpl<T> list = this;
        return new Iterator<T>() {

            final Node<T> first = list.first;
            Node<T> current = null;

            @Override
            public boolean hasNext() {

                if (list.first == null)
                    return false;
                else if (current == null)
                    return true;
                else if (current == list.last)
                    return false;
                return true;
            }

            @Override
            public T next() {
                if (list.first == null) throw new NoSuchElementException();
                else if (current == null) {
                    this.current = first;
                    return current.element;
                } else if (current.next == null)
                    throw new NoSuchElementException();
                this.current = current.next;
                return current.element;
            }
        };
    }

    @Override
    public void addFirst(T element) {
        Node<T> newNode = new Node<>(element);
        if (first == null) {
            first = last = newNode;
        } else {
            newNode.next = first;
            first = newNode;
        }

    }

    @Override
    public void addLast(T element) {

        Node<T> newNode = new Node<>(element);
        if (first == null) {
            first = last = newNode;
        } else {
            last.next = newNode;
            last = newNode;
        }
        size++;

    }

    @Override
    public void removeFirst() throws NoSuchFieldException {
        if (first == null) {
            throw new NoSuchFieldException();
        } else {
            first = first.next;
        }
        size--;
    }

    @Override
    public void removeLast() throws NoSuchFieldException {
        if (first == null) {
            throw new NoSuchFieldException();
        } else {
            Node<T> prev = first;
            while (prev.next != last) {
                prev = prev.next;
            }
            last = prev;
            last.next=null;
        }
        size--;

    }

    @Override
    public T getFirst() {
        return first.element;
    }

    @Override
    public T getLast() {

        return last.element;
    }

    @Override
    public T search(Object _element) {

        Node<T> current = first;
        for (int i = 0; i < size(); i++) {
            if (current.element.equals(_element)) return current.element;
            current = current.next;
        }

        return null;
    }

    @Override
    public boolean remove(T _element) throws NoSuchFieldException, IllegalAccessException {

        Field field = _element.getClass().getDeclaredField("city");
        field.setAccessible(true);
        Object value = field.get(_element);
        Field field2 = first.element.getClass().getDeclaredField("city");
        field.setAccessible(true);
        Object value2 = field2.get(first.element);
        Field field3 = last.element.getClass().getDeclaredField("city");
        field.setAccessible(true);
        Object value3 = field2.get(last.element);
        boolean check=false;
        if (value2.equals(value)) {
            removeFirst();

        } else if (value3.equals(value)) {
            removeLast();
        } else {
            Node<T> current = first.next;
            int count=0;
            for(int i=0;i<size(); i++)
            {
                count++;
                Field field4 = current.element.getClass().getDeclaredField("city");
                field.setAccessible(true);
                Object value4 = field2.get(current.element);
                if(value4.equals(value)) {
                    Node<T> prev = getNodeByIndex(count-1);
                    _element=prev.next.element;
                    prev.next=prev.next.next;
                    check=true;
                    return check;
                }else
                    current=current.next;

            }

        }
        size=size();
        return check;
    }

    public void main() throws NoSuchFieldException, IllegalAccessException, JsonProcessingException {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        System.out.println(raw.write(cities));
        cities.remove(new CITY("Ivano-Frankivsk"));
        cities.removeLast();
        cities.addLast(new CITY("Uzhorod"));
        cities.removeFirst();
        cities.remove(new CITY("Odesa"));
        System.out.println(raw.write(cities));
        cities.clear();
        cities.addLast(new CITY("Odesa"));
        cities.addLast(new CITY("Kyiv"));
        System.out.println(raw.write(cities));


    }
}
