package ua.univer.practice3.Task2;

import java.util.*;
import java.util.function.Consumer;

public class IntStringCappedMap {

    public class Entry {

        private Integer key;
        private String value;
        private Entry next;

        public Entry(Integer key, String value, Entry next) {
            this.key = key;
            this.value = value;
            this.next = next;
        }

        public Integer getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }

        public void setKey(Integer key) {
            this.key = key;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public Entry getNext() {
            return next;
        }

        public void setNext(Entry next) {
            this.next = next;
        }

        @Override
        public String toString() {
            Entry temp = this;
            StringBuilder sb = new StringBuilder();
            while (temp != null) {
                sb.append(temp.key + "=" + temp.value);
                temp = temp.next;
            }
            return sb.toString();
        }

    }

    private int size = 16;
    private int capacity;

    public Entry[] getTable() {
        return table;
    }

    private Entry[] table;


    public IntStringCappedMap(int capacity) {
        this.capacity = capacity;
        table = new Entry[size];
    }

    public IntStringCappedMap() {
        table = new Entry[size];
    }

    public void put(Integer key, String value) {
        int temp = 0;
        for (var i : table) {
            if (i != null)
                temp = i.getValue().toString().length() + temp;
        }
        temp = temp + value.length();

        int index = key.hashCode() % size;
        Entry newEntry = new Entry(key, value, null);

        if (capacity < temp) {
            for (int i = 0; i < size; i++) {
                if (table[i] != null) {
                    table[i] = null;
                    break;
                }
            }
        }

        if (table[index] == null) {
            table[index] = newEntry;
        } else {
            Entry previousNode = null;
            Entry current = table[index];
            while (current != null) {
                if (current.getKey().equals(key)) {
                    current.setValue(value);
                }
                previousNode = current;
                current = current.next;
            }
        }
    }

    public String get(Integer key) {
        String value = null;
        int index = key.hashCode() % size;
        Entry current = table[index];
        while (current != null) {
            if (current.getKey().equals(key)) {
                value = current.getValue();
                break;
            }
            current = current.next;
        }
        return value;
    }

    public void remove(Integer key) {
        int index = key.hashCode() % size;
        Entry previous = null;
        Entry current = table[index];

        while (current != null) {
            if (current.getKey().equals(key)) {
                if (previous == null) {
                    current = current.next;
                    table[index] = current;
                    return;
                } else {
                    previous.setNext(current.getNext());
                    return;
                }
            }
            previous = current;
            current = current.next;
        }
    }

    public int size() {
        int temp = 0;
        for (int i = 0; i < size; i++) {
            if (table[i] != null) {
                temp = temp + 1;
            }
        }

        return temp;
    }

    public Set<Entry> entrySet() {
        Set<Entry> entrySet = new HashSet<>();

        Entry[] newtable = new Entry[size];

        for (int i = 0; i < table.length; i++) {
            if (newtable[i] != null) {
                entrySet.add(newtable[i]);
            }
        }
        return entrySet;
    }

    public boolean hasNext() {
        for (int i = 0; i < table.length; i++) {
            if (table[i] != null) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{ ");
        for (int i = 0; i < size; i++) {
            if (table[i] != null)
                sb.append(table[i] + ", ");
        }
        sb.append(" }");
        return sb.toString();
    }

}

