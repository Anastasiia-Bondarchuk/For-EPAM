package ua.univer.practice3.Task2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IntStringCappedMapTest {

    @Test
    void put() {

        IntStringCappedMap map = new IntStringCappedMap(20);
        map.put(5, "Five");
        map.put(6, "Six");
        map.put(7, "Seven");
        boolean check = false;
        for(var i: map.getTable())
        {
            if(i!=null && i.getValue()=="Seven")
                check=true;
        }
        assertEquals(check, true);
    }

    @Test
    void get() {
        IntStringCappedMap map = new IntStringCappedMap(20);
        map.put(5, "Five");
        map.put(6, "Six");
        map.put(7, "Seven");
        assertEquals(map.get(6), "Six");
    }

    @Test
    void remove() {

        IntStringCappedMap map = new IntStringCappedMap(20);
        map.put(5, "Five");
        map.put(6, "Six");
        map.put(7, "Seven");
        map.remove(7);
        boolean check = false;
        for(var i: map.getTable())
        {
            if(i!=null && i.getValue()=="Seven")
                check=true;
        }
        assertEquals(check, false);
    }

    @Test
    void size() {
        IntStringCappedMap map = new IntStringCappedMap(20);
        map.put(5, "Five");
        map.put(6, "Six");
        map.put(7, "Seven");
        assertEquals(map.size(), 3);
    }
}