package ua.univer.practice3.Task3.SecondPart;

import java.util.function.Consumer;

public class main {
    public static void main(String[] args) {
        SortedByAbsoluteValue my = new SortedByAbsoluteValue();
        my.add(8);
        my.add(9);
        my.add(5);
        my.add(95);
        my.delete(95);

        SortedByAbsoluteValue second = new SortedByAbsoluteValue();
        second.add(123);
        second.add(223);
        second.addCollection(my);

        second.inOrderTraversal();
    }
}
