package ua.univer.practice3.Task3.ThirdPart;

import ua.univer.practice3.Task3.FirstPart.PairStringListImpl;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class MedianQueue implements Iterable{

    static class Node {
        Integer element;
        Node next;

        public Node(Integer element) {
            this.element = element;
        }

        @Override
        public String toString() {
            return "" + element + ' ';
        }
    }

    Node head;

    public int size()
    {
        Node current = head;
        int count=0;
        while(current!=null)
        {
            count=count+1;
            current=current.next;
        }
        return count;
    }

    public void offer(Integer element) {
        Node current = new Node(element);
        current.next=null;
        if(head==null)
        {
            head = current;
        }else{
            Node temp = head;
            while(temp.next!=null)
            {
                temp=temp.next;
            }
            temp.next=current;
        }
    }

    public boolean contains(Integer value) {

        Node current = new Node(value);
        Node first = head;
        while(first.next!=null)
        {
            if(first.element.compareTo(value)==0)
            return true;
            first=first.next;
        }
        if(first.element.compareTo(value)==0)
            return true;
        return false;
    }

    public void poll()
    {
        head=head.next;
    }

    public int median()
    {
        Node current=head;
        int temp = size()/2;
        int secondPart = size()-temp;
        if(temp==secondPart)
        {
            for(int i=0;i<temp-1;i++)
            {
                current=current.next;
            }
            Node current2=head;
            for(int i=0;i<temp;i++)
            {
                current2=current2.next;
            }
            if(current.element>current2.element)
                return current2.element;
        }else
        {
            for(int i=0;i<temp;i++)
            {
                current=current.next;
            }
        }
        return current.element;
    }

    public Integer peek()
    {
        return head.element;
    }

    @Override
    public String toString() {
        String result = "";
        Node current = head;
        result = current.element.toString();
        current=current.next;
        while (current.next != null) {
            result = result + " " + current.element;
            current = current.next;
        }
        result = result+ " " + current.element+" --> "+median();
        return result;
    }

    public Iterator<Integer> iterator() {
        Node firstNode = head;
        return new Iterator<Integer>() {
            Node currentNode = null;

            @Override
            public boolean hasNext() {
                if (firstNode == null) {
                    return false;
                } else if (currentNode == null) {
                    return true;
                } else if (currentNode.next == null) {
                    return false;
                }
                return true;
            }

            @Override
            public Integer next() {
                if (firstNode == null) {
                    throw new NoSuchElementException();
                } else if (currentNode == null) {
                    this.currentNode = firstNode;
                    return currentNode.element;
                } else if (currentNode.next == null) {
                    throw new NoSuchElementException();
                }
                this.currentNode = currentNode.next;
                return currentNode.element;
            }
        };
    }
}
