package ua.univer.practice1.Task2;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayImpl <T>implements Array<T>{

    private T [] array;
    int n;

    public ArrayImpl(T [] _array)
    {
        n=_array.length;
        array = (T[])java.lang.reflect.Array.newInstance(_array.getClass().getComponentType(), n);
        for(int i=0;i<n;i++)
        {
            array[i]=_array[i];
        }

    }

    @Override
    public void add(T element) {

        n = array.length;
        T[] newarray = (T[])java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), n);;
        for(int i=0;i<n;i++)
        {
            newarray[i]=array[i];
        }
        array = (T[])java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), 1+n);
        for(int i=0;i<n;i++)
        {
            array[i]=newarray[i];
        }
        array[n]=element;
    }

    @Override
    public void set(int index, T element) {

        n=array.length;
        T[] newarray = (T[])java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), n);;
        for(int i=0;i<n;i++)
        {
            newarray[i]=array[i];
        }
        array = (T[])java.lang.reflect.Array.newInstance(newarray.getClass().getComponentType(), 1+n);
        for(int i=n;i>index;i--)
        {
            array[i]=newarray[i-1];
        }
        for(int i=0;i<index;i++)
        {
            array[i]=newarray[i];
        }
        array[index]=element;

    }

    @Override
    public T get(int index) {

        return array[index];
    }

    @Override
    public int indexOf(Object element) throws Exception {

        boolean check=false;
        n=array.length;
        int i=0;
        for(;i<n;i++)
        {
            if(element==array[i])
            {
                check=true;
                return i;

            }
        }
        if(!check)
        {
            throw new NoSuchElementException();
        }
        return 0;

    }

    @Override
    public void remove(int index) {

        n=array.length;
        T[] newarray = (T[])java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), n);;
        for(int i=0;i<n;i++)
        {
            newarray[i]=array[i];
        }
        array = (T[])java.lang.reflect.Array.newInstance(newarray.getClass().getComponentType(), n-1);
        for(int i=n-1;i>index;i--)
        {
            array[i-1]=newarray[i];
        }
        for(int i=0;i<index;i++)
        {
            array[i]=newarray[i];
        }

    }

    @Override
    public void clear() {
        array =  (T[])java.lang.reflect.Array.newInstance(array.getClass().getComponentType(), 0);
    }

    @Override
    public int size() {
        return array.length;
    }

    @Override
    public Iterator<T> iterator() {

        Iterator<T> iter = java.util.Arrays.stream(array).iterator();
        return iter;
    }

    @Override
    public String toString()
    {
        return java.util.Arrays.toString(array);
    }
}
