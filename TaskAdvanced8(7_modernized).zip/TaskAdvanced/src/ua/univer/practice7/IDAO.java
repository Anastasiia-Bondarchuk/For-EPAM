package ua.univer.practice7;

import java.util.List;

public interface IDAO {

    public List<Movie> findmovie(int year);
    public String actorsInfo(String movieName);
    public String actorsInfo();
    public boolean deleteMovie(int years) throws Exception;
}
