package ua.univer.practice7;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

public class AccessToDatabase {

    private static final String URL = "jdbc:Mysql://localhost:3306/homecinema";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1234";

    private List<Movie> movies = new ArrayList<>();

    public AccessToDatabase() {
        Connection connection=null;
        ResultSet resultSet=null;
        try{

            List<String> actorsNames=new ArrayList<>();
            List<Actor> actors = new ArrayList<>();
            List<Director> directors = new ArrayList<>();

            connection = DriverManager.getConnection(URL,USERNAME, PASSWORD);
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from actor");

            while(resultSet.next())
            {
                actors.add(new Actor(resultSet.getString("actor_name"), resultSet.getString("actor_surname"),
                        resultSet.getString("actor_birth")));
            }

            resultSet = statement.executeQuery("select * from director");
            while(resultSet.next())
            {
                directors.add(new Director(resultSet.getString("director_name"), resultSet.getString("director_surname"),
                        resultSet.getString("director_birth")));
            }

            resultSet = statement.executeQuery("select * from movies");
            while(resultSet.next())
            {
                String nameOfDirector = resultSet.getString("movie_director");
                Director director=null;
                for(Director _director:directors)
                {
                    if((_director.getName()+" "+_director.getSurname()).equals(nameOfDirector))
                        director=_director;
                }

                String namesOfActors = resultSet.getString("movie_actors");
                String [] arrayCast = namesOfActors.split(", ");
                List <Actor> cast = new ArrayList<>();
                for(int i=0;i< arrayCast.length;i++)
                {
                    arrayCast[i]=arrayCast[i].replace(",", "");
                    for(Actor actor:actors)
                    {
                        if((actor.getName()+" "+actor.getSurname()).compareTo(arrayCast[i])==0)
                        {
                            cast.add(actor);
                        }
                    }
                }

                movies.add(new Movie(resultSet.getString("movie_name"), cast, resultSet.getString("movie_date"),
                        resultSet.getString("movie_country"), director));
            }

        }catch(SQLException sqlEx)
        {
            sqlEx.printStackTrace();
        }finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public List<Movie> findmovie(int year)
    {
        List<Movie> newList=new ArrayList<>();
        final int ourYear=20;
        for(Movie movie: movies)
        {
            String [] DayMonthYear=movie.getDate().split("/");
            for(int i=0;i< DayMonthYear.length;i++)
            {
                DayMonthYear[i]=DayMonthYear[i].replace("/","");
            }
            int difference = ourYear-Integer.parseInt(DayMonthYear[2]);
            if(difference==year||difference==(year-1))
                newList.add(movie);
        }
        return newList;
    }
    public String actorsInfo(String movieName)
    {
        for(Movie movie: movies)
        {
            if(movie.getName().equals(movieName))
            {
                String toReturn ="";
                for(Actor actor: movie.getActors())
                {
                    toReturn+=actor;
                }
                return toReturn;
            }
        }
        return null;
    }
    public String actorsInfo()
    {
        List <Actor> actors= new ArrayList<>();
        List <Actor> allActors= new ArrayList<>(); //we will be trying to find there actors who are repeated in movies
        for(Movie movie: movies)
        {
            for(Actor actor: movie.getActors())
            {
                allActors.add(actor);
            }
        }
        Actor [] actorArray = allActors.toArray(new Actor[allActors.size()]);

        for (int i = 0; i < actorArray.length; i++) {
            for (int j = i+1; j < actorArray.length; j++) {
                if(actorArray[i]==actorArray[j])
                    actors.add(actorArray[j]);
            }
        }
        String toReturn ="";
        for(Actor actor: actors)
        {
            toReturn+=actor;
        }
        return toReturn;
    }
    public boolean deleteMovie(int years) throws Exception {
        Connection connection = null;
        ResultSet resultSet = null;
        Statement statement = null;
        final int ourYear=22;
        try{
            List<Movie> forDeleting=new ArrayList<>();
            for(Movie movie: movies)
            {
                String [] DayMonthYear=movie.getDate().split("/");
                for(int i=0;i< DayMonthYear.length;i++)
                {
                    DayMonthYear[i]=DayMonthYear[i].replace("/","");
                }
                if((ourYear-Integer.parseInt(DayMonthYear[2]))>years)
                    forDeleting.add(movie);

            }
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            statement = connection.createStatement();

            if(!forDeleting.isEmpty())
            {
                for (Movie movie: forDeleting) {
                statement.executeUpdate("DELETE FROM movies WHERE movie_name = " + movie.getName());
                movies.remove(movie);
            }

            }else return false;
        }catch(SQLException sqlEx)
        {
            sqlEx.printStackTrace();
        }finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }
    @Override
    public String toString() {

        String outPut="";
        for (Movie movie:movies) {
            outPut+=movie+"\n";
        }
        return "List of movies: "+outPut;
    }
}
