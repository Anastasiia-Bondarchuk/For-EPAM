package ua.univer.practice7;

import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class IDAOImplTest {

    IDAOImpl idao = new IDAOImpl();
    @Test
    void findmovie() {

        assertEquals(idao.findmovie(2).get(0).getName(),"Carnival Row");
    }

    @Test
    void actorsInfo() {
        assertEquals(true, idao.actorsInfo().contains("Orlando Bloom"));
    }

    @Test
    void testActorsInfo() {
        assertEquals(true, idao.actorsInfo("Fantastic Beasts").contains("Jonny Depp"));
    }

    @Test
    void deleteMovie() throws Exception {
        assertEquals(false, idao.deleteMovie(25));
    }
}