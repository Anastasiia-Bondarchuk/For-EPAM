package ua.univer.practice7;

import java.util.List;

public class Movie {

    private String name;
    private List<Actor> actors;
    private String date;
    private String country;
    private Director director;

    public Movie(String name, List<Actor> actors, String date,
                 String country, Director director) {
        this.name = name;
        this.actors = actors;
        this.date = date;
        this.country = country;
        this.director = director;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Actor> getActors() {
        return actors;
    }

    public void setActors(List<Actor> actors) {
        this.actors = actors;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Director getDirector() {
        return director;
    }

    public void setDirector(Director director) {
        this.director = director;
    }

    @Override
    public String toString() {
        String listofactors="";
        for(Actor actor: actors)
        {
            listofactors+=actor;
        }
        return "\nMovie: "+name+"\nRelease: "+date+"\nCountry: "+country+"\nDirected by "+director+"\nActors: "+listofactors;
    }
}
