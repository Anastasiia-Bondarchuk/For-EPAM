package ua.univer.practice7;

public class Director extends Actor{

    public Director(String name, String surname, String birth) {
        super(name, surname, birth);
    }
}
