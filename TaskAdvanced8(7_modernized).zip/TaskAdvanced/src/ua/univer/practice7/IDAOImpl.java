package ua.univer.practice7;

import java.util.ArrayList;
import java.util.List;

public class IDAOImpl implements IDAO {

    AccessToDatabase access;
    public IDAOImpl() {
        access = new AccessToDatabase();
    }

    public List<Movie> findmovie(int year)
    {
        return access.findmovie(year);
    }

    public String actorsInfo(String movieName)
    {
        return access.actorsInfo(movieName);
    }

    public String actorsInfo()
    {
        return access.actorsInfo();
    }

    public boolean deleteMovie(int years) throws Exception
    {
        return access.deleteMovie(years);
    }

    @Override
    public String toString() {
        return access.toString();
    }
}
