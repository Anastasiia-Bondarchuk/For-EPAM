package ua.univer.practice6.strategy.cards;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class main {
    class CardImpl implements Card {

        private String name;

        CardImpl(final String name) {
            this.name = name;
        }

        CardImpl(final int name) {
            this(Integer.toString(name));
        }

        @Override
        public String name() {
            return name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    class DeckImpl implements Deck {

        LinkedList<Card> cards;

        public DeckImpl(final int cardsAmount) {
            this.cards = new LinkedList<>();
            for (int i = 0; i < cardsAmount; i++) {
                cards.push(new ua.univer.practice6.strategy.cards.CardImpl(i));
            }
        }

        @Override
        public Card dealCard() {
            return cards.size() == 0 ? null : cards.pop();
        }

        @Override
        public List<Card> restCards() {
            final ArrayList<Card> rest = new ArrayList<>(this.cards);
            cards.clear();
            return rest;
        }

        @Override
        public int size() {
            return cards.size();
        }


    }
    public static void main(String[] args) {
        final Deck deck = new ua.univer.practice6.strategy.cards.DeckImpl(52);
        final CardDealingStrategy strategy = CardDealingStrategies.texasHoldemCardDealingStrategy();
        strategy.dealStacks(deck,3).toString();
    }
}
