package ua.univer.practice6.strategy.cards;


import ua.univer.practice6.Named;

public interface Card extends Named {
    String name();
}
