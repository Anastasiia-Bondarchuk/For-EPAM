package ua.univer.practice6.strategy.cards;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CardDealingStrategies {
    public static CardDealingStrategy texasHoldemCardDealingStrategy() {
       return null;
    }

    public static CardDealingStrategy classicPokerCardDealingStrategy() {
        return new CardDealingStrategy() {
            @Override
            public Map<String, List<Card>> dealStacks(Deck deck, int players) {
                Map <String, List<Card>>map = new HashMap();
                List <List<Card>>listofLists = new ArrayList();
                for(int i=0;i<players;i++)
                {
                    listofLists.add(new ArrayList<>());
                }
                while(!(deck.restCards().size()<players))
                {
                    for (int i=0;i<players;i++)
                    {
                        listofLists.get(i).add(deck.dealCard());
                        map.put("Player"+(i+1), listofLists.get(i));
                    }
                }
                return map;
            }
        };
    }

    public static CardDealingStrategy bridgeCardDealingStrategy(){
        throw new UnsupportedOperationException();
    }

    public static CardDealingStrategy foolCardDealingStrategy(){
        throw new UnsupportedOperationException();
    }

}
