package ua.univer.practice6.iterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

class Iterators {

    private static Iterator<Integer> times(int[] array, int times) {
        int array1[] = new int[array.length * times];
        int j = 0;
        for (int i = 0; i < array.length; i++) {
            int counter = 0;
            for (; counter < times; ) {
                array1[j] = array[i];
                counter++;
                j++;
            }
        }

        Iterator<Integer> iterator = new Iterator<Integer>() {
            int index;

            @Override
            public boolean hasNext() {
                return index < array1.length;
            }

            @Override
            public Integer next() {
                if (index == array1.length)
                    throw new NoSuchElementException();
                else {
                    return Integer.valueOf(array1[index++]);
                }

            }
        };
        return iterator;
    }


    public static Iterator<Integer> intArrayTwoTimesIterator(int[] array) {
        try {
            return times(array, 2);
        } catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }

    public static Iterator<Integer> intArrayThreeTimesIterator(int[] array) {
        try {
            return times(array, 3);
        } catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }

    public static Iterator<Integer> intArrayFiveTimesIterator(int[] array) {
        try {
            return times(array, 5);
        } catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }

    public static Iterable<String> table(String[] columns, int[] rows) {
        try {
            List array = new ArrayList<String>();
            for (int i = 0; i < columns.length; i++) {
                for (int j = 0; j < rows.length; j++) {
                    array.add(columns[i].toString() + rows[j]);
                }
            }
            return array;
        }
        catch(Exception e){
                throw new UnsupportedOperationException();
            }

        }
    }
