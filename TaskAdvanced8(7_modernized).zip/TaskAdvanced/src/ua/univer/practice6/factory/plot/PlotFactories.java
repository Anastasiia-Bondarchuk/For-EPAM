package ua.univer.practice6.factory.plot;

class PlotFactories {

    public PlotFactory classicDisneyPlotFactory(Character hero, Character beloved, Character villain) {

        try{return new ClassicPlot( hero,  beloved,  villain);} catch (Exception e) {
            throw new UnsupportedOperationException();
        }

    }

    public PlotFactory contemporaryDisneyPlotFactory(Character hero, EpicCrisis epicCrisis, Character funnyFriend) {
        try{return new ContemporaryPlot( hero,  epicCrisis,  funnyFriend);} catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }

    public PlotFactory marvelPlotFactory(Character[] heroes, EpicCrisis epicCrisis, Character villain) {
        try{return new MarvelPlot(heroes,  epicCrisis,  villain);} catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }
}
