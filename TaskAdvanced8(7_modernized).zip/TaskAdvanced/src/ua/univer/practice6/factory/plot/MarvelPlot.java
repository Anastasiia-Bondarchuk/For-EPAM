package ua.univer.practice6.factory.plot;

public class MarvelPlot implements PlotFactory{

    String[]heroes;
    String epicCrisis, villain;

    public MarvelPlot(Character[] heroes, EpicCrisis epicCrisis, Character villain) {
        int count=0;
        this.heroes=new String[heroes.length];
        while(count!= heroes.length)
        {
            this.heroes[count]=heroes[count].name();
            count++;
        }
        this.epicCrisis = epicCrisis.name();
        this.villain = villain.name();
    }

    @Override
    public String plot() {

        String plot =epicCrisis+" threatens the world. But ";
        for(int i=0;i< heroes.length;i++)
        {
            if(i!= heroes.length-1)
             plot+="brave "+heroes[i]+", ";
            else plot+="brave "+heroes[i]+" ";
        }

        return plot+"on guard. So, no way that intrigues of " +villain+ " overcome the willpower of inflexible heroes";
    }
}
