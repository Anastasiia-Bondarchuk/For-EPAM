package ua.univer.practice6.factory.plot;

import ua.univer.practice6.Named;

@FunctionalInterface
public interface Character extends Named {
}
