package ua.univer.practice6.decorator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class DecoratedList implements Read{
    private List<String> sourceList;

    public DecoratedList(List<String> sourceList) {
        this.sourceList = sourceList;
    }

    @Override
    public String get(int index) {
        int count=0;
        for(String string: sourceList)
        {
            if(count==index)
                return string;
            count++;
        }
        return null;
    }

    @Override
    public int size() {
        int count=0;
        for(String string: sourceList)
            count++;
        return count;
    }

    class MyIterator implements Iterator
    {
        int current =0;
        @Override
        public boolean hasNext() {
            if(sourceList.get(current+1)==null)
                return false;
            else return true;
        }

        @Override
        public Object next() {
            current++;
            return sourceList.get(current);
        }
    }

    public static List<String> evenIndexElementsSubList(List<String> sourceList) {
        List<String> newList = new ArrayList<>();
        int count=0;
        for(String string: sourceList)
        {
            if(count%2==0)
            {
                newList.add(string);
            }
            count++;
        }
        return newList;
    }
}
