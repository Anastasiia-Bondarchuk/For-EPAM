package ua.univer.practice6;

public interface Named {
    String name();
}
