SELECT * FROM homecinema.actor;
UPDATE actor
SET actor_surname = 'Redman'
WHERE actor_id=4;





