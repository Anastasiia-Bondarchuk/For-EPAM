package ua.univer.practice2.Task2;

import ua.univer.practice1.Task2.Container;

public interface Queue<T> extends Container<T> {

    // Appends the specified element to the end.
    void enqueue(T element);

    // Removes the head.
    T dequeue();

    // Returns the head.
    T top();
}
