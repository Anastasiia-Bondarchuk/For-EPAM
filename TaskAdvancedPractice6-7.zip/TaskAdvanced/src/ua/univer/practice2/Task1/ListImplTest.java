package ua.univer.practice2.Task1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ListImplTest {

    @Test
    void clear() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        cities.clear();
        assertEquals(null, cities.getNodeByIndex(1));
    }

    @Test
    void size() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);

        assertEquals(7, cities.size());
    }

    @Test
    void getNodeByIndex() {

        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        assertEquals("Kharkiv", cities.getNodeByIndex(1).element.getCity());
    }

    @Test
    void addFirst() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        cities.addFirst(new CITY("Vinnytsya"));
        assertEquals("Vinnytsya", cities.getNodeByIndex(0).element.getCity());
    }

    @Test
    void addLast() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        cities.addLast(new CITY("Vinnytsya"));
        assertEquals("Vinnytsya", cities.getNodeByIndex(cities.size()-1).element.getCity());
    }

    @Test
    void removeFirst() throws NoSuchFieldException {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        cities.removeFirst();
        assertEquals("Kharkiv", cities.getNodeByIndex(0).element.getCity());
    }

    @Test
    void removeLast() throws NoSuchFieldException {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        cities.removeLast();
        assertEquals("Lviv", cities.getNodeByIndex(cities.size()-1).element.getCity());
    }

    @Test
    void getFirst() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        assertEquals("Kyiv", cities.getFirst().getCity());
    }

    @Test
    void getLast() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        assertEquals("Ivano-Frankivsk", cities.getLast().getCity());
    }

    @Test
    void search() {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        assertEquals(null, cities.search("fdvdfbf"));
    }

    @Test
    void remove() throws NoSuchFieldException, IllegalAccessException {
        ListImpl <CITY> cities= new ListImpl<>();
        ReadAndWrite<CITY> raw = new ReadAndWrite<>();
        raw.read(cities);
        cities.remove(new CITY("Kyiv"));
        assertEquals("Kharkiv", cities.getNodeByIndex(0).element.getCity());
    }
}