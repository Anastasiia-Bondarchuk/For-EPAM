package ua.univer.practice7;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccessToDatabaseTest {

    @Test
    void findmovie() {
        AccessToDatabase access= new AccessToDatabase();
        assertEquals(access.findmovie(2).get(0).getName(),"Carnival Row");
    }

    @Test
    void actorsInfo() {
        AccessToDatabase access= new AccessToDatabase();
        assertEquals(true, access.actorsInfo().contains("Orlando Bloom"));
    }

    @Test
    void testActorsInfo() {
        AccessToDatabase access= new AccessToDatabase();
        assertEquals(true, access.actorsInfo("Fantastic Beasts").contains("Jonny Depp"));
    }
}