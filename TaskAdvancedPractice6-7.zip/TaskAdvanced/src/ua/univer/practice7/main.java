package ua.univer.practice7;

public class main {
    public static void main(String[] args) {
        AccessToDatabase access= new AccessToDatabase();
        System.out.println(access+"\n");
        System.out.println(access.actorsInfo());
        System.out.println(access.actorsInfo("Pirates Of Caribbean"));
        System.out.println(access.findmovie(2));
    }
}
