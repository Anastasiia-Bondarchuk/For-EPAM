package ua.univer.practice4.Task1;

public class main {

    public static void main(String[] args) {
        MyThreadExtd extd = new MyThreadExtd();
        Thread impl = new Thread(new MyThreadImpl());
        extd.start();
        try {
            extd.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        impl.start();
    }
}
