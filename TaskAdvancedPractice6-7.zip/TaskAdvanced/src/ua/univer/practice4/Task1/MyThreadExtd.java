package ua.univer.practice4.Task1;

public class MyThreadExtd extends Thread{

    String name="Maria";

    @Override
    public void run()
    {
        long t = System.currentTimeMillis();
        long end = t+2000;
        while(System.currentTimeMillis()<end)
        {
            System.out.println(name);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }


}
