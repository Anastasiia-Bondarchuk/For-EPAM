package ua.univer.practice5.Task3;

public class Passengers implements Runnable{

    private Airport airport;
    private int planeType;

    public Passengers(Airport airport, int planeType) {
        this.airport = airport;
        this.planeType = planeType;
    }


    @Override
    public void run() {

        try {

            while(true)
            {
                Thread.currentThread().setName("Passengers are coming: " + planeType);
                Thread.sleep(500);
                Plane plane = airport.getPlane(planeType);
                if(plane!=null)
                {
                    while (plane.countCheck())
                    {
                        Thread.sleep(100);
                        plane.add(10);
                        System.out.println(plane.getCount()+"Plane is full\n"+Thread.currentThread().getName());

                    }
                }
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
