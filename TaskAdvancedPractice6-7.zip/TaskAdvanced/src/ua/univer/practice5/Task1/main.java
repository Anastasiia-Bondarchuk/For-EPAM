package ua.univer.practice5.Task1;

public class main {

    public static void main(String[] args) {

        Thread t = new Thread(new Process(5));
        Thread t1 = new Thread(new Process(5));
        Thread t2 = new Thread(new Process(5));
        t.start();
        t1.start();
        t2.start();
    }
}
