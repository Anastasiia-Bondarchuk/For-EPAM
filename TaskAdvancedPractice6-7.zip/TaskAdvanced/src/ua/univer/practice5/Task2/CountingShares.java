package ua.univer.practice5.Task2;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

public class CountingShares implements Runnable{

    private StockExchanges se;
    private final double percentage =100;
    private final int maxAmountOdSales =100;

    @Override
    public String toString() {
        return "CountingShares: " + se;
    }

    public CountingShares(StockExchanges _se) {
        se = _se;
    }

    public synchronized void counting()
    {
        List <Firm> firms = new ArrayList<>();
        firms=se.getFirms();

        for(Firm firm:firms)
        {
            for(Share share:firm.getShares())
            {
                Share prev = new Share(share.getAmountOfSales());
                prev.setPercentage(share.getPercentage());
                prev.setCost(share.getCost());

                share.setAmountOfSales((int)(Math.random()*maxAmountOdSales));
                if(prev.getAmountOfSales()==0)
                {
                    prev.setAmountOfSales(1);
                }
                if(share.getAmountOfSales()> prev.getAmountOfSales())
                {
                    double difference = (share.getAmountOfSales()- prev.getAmountOfSales());
                    double next = difference/ prev.getAmountOfSales()*percentage;
                    share.setPercentage((share.getPercentage()+difference));
                    share.setCost((int)(share.getCost()+share.getCost()*((share.getPercentage()-prev.getPercentage())/percentage)));
                }else if(share.getAmountOfSales()< prev.getAmountOfSales())
                {
                    double difference = (prev.getAmountOfSales()- share.getAmountOfSales());
                    double next = difference/ prev.getAmountOfSales()*percentage;
                    share.setPercentage((share.getPercentage()-difference));
                    share.setCost((int)(share.getCost()-share.getCost()*((prev.getPercentage()-share.getPercentage())/percentage)));
                }
            }
        }

        se.setFirms(firms);
    }

    public synchronized void isWorking()
    {
        while(!se.isStop())
        {
            double check =0;
            int checkcost=0;
            se.setIndex(0);
            for (Firm firm: se.getFirms()) {
                check+=firm.getPercentage();
                se.setIndex((se.getIndex()+firm.getPercentage()));
            }
            se.setIndex(se.getIndex()/se.getFirms().size());

            for (Firm firm: se.getFirms()) {
                for(Share share: firm.getShares())
                {
                    checkcost+=share.getCost();
                }
            }
            if(check!=se.getFirms().size()*100)
            {
                if(se.getIndex()<120||checkcost==0)
                    se.setStop(true);
                else {
                    System.out.println(se);
                    counting();
                }
            }else {
                System.out.println(se);
                counting();
            }
        }

    }


    @Override
    public void run() {

        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        while(!se.isStop())
        {
           isWorking();
           System.out.println(se);
        }
        lock.unlock();
        System.out.println("Shares are down");
    }
}
