package ua.univer.practice3.Task3.FirstPart;

public class main {

    public static void main(String[] args) {

        PairStringListImpl my = new PairStringListImpl();
        my.add("1");
        my.add("2");
        my.add("3");
        my.add("4");
        my.deletebyIndex(1);
        my.contains("4");

        System.out.println(my.contains("4"));
        System.out.println(my);

        PairStringListImpl second = new PairStringListImpl();
        second.add("wow");
        second.add("aww");
        second.add("cute");
        second.add("qwq");
        second.addCollectionByIndex(3,my);



        System.out.println(second);
    }
}
