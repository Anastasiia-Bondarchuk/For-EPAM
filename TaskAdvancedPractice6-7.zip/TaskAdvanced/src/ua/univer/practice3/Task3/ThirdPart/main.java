package ua.univer.practice3.Task3.ThirdPart;

public class main {

    public static void main(String[] args) {

        MedianQueue my = new MedianQueue();

        int n=0;
        for(int i=0;i<8;i++)
        {
            n=(int)(Math.random()*10);
            my.offer(n);
        }

        my.poll();

        System.out.println(my);
    }
}
