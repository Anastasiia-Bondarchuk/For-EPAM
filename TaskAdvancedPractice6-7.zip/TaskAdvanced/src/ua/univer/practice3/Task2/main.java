package ua.univer.practice3.Task2;

import java.util.HashMap;

public class main {

    public static void main(String []args)
    {
        IntStringCappedMap map = new IntStringCappedMap(40);
        map.put(5, "Five");
        map.put(6, "Six");
        map.put(7, "Seven");
        map.put(8, "Eight");
        map.put(12, "Twelve");
        map.put(9, "Nine");
        map.put(1, "One");
        map.remove(12);


        System.out.println(map);
        System.out.println(map.size());
        System.out.println(map.get(6));
    }
}
