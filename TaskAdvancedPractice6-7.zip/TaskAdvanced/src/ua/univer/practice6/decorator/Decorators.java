package ua.univer.practice6.decorator;

import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

public class Decorators extends DecoratedList{

    public Decorators(List<String> sourceList) {
        super(sourceList);
    }

    public static List<String> evenIndexElementsSubList(List<String> sourceList) {
        try{
            return DecoratedList.evenIndexElementsSubList(sourceList);
        }
        catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }


}
