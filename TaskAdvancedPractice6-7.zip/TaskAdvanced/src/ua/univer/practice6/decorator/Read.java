package ua.univer.practice6.decorator;

import java.util.Iterator;
import java.util.List;

public interface Read{
    String get(int index);
    int size();
}
