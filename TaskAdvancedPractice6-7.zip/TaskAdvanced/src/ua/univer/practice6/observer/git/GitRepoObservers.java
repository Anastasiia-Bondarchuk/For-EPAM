package ua.univer.practice6.observer.git;

import java.util.ArrayList;
import java.util.List;

public class GitRepoObservers {

    public static Repository newRepository(){

        try{

            List<Commit> com = new ArrayList<>();
            Repository repository = new Repository() {
                @Override
                public void addWebHook(WebHook webHook) {

                }

                @Override
                public Commit commit(String branch, String author, String[] changes) {

                    return null;
                }

                @Override
                public void merge(String sourceBranch, String targetBranch) {

                }
            };
            return repository;
        } catch (Exception e) {
            throw new UnsupportedOperationException();
        }
    }

    public static WebHook mergeToBranchWebHook(String branchName){
        return null;
    }

    public static WebHook commitToBranchWebHook(String branchName){
        return null;
    }


}
