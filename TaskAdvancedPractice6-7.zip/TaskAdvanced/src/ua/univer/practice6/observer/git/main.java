package ua.univer.practice6.observer.git;

public class main {
    public static void main(String[] args) {
        final Repository repo = GitRepoObservers.newRepository();

        final WebHook commitMasterWebHook = GitRepoObservers.commitToBranchWebHook("master");
        final WebHook commitReadmeWebHook = GitRepoObservers.commitToBranchWebHook("dev-readme");
        final WebHook mergeMasterBranch = GitRepoObservers.mergeToBranchWebHook("master");

        repo.addWebHook(mergeMasterBranch);
        repo.addWebHook(commitMasterWebHook);
        repo.addWebHook(commitReadmeWebHook);

        repo.commit(
                "dev-readme",
                "Johnny Mnemonic",
                new String[]{
                        "Added README.md",
                        "Added project description",
                });
        repo.commit(
                "dev-readme",
                "Johnny Mnemonic",
                new String[]{
                        "Added functional requirements",
                });
        repo.commit(
                "dev-readme",
                "Johnny Silverhand",
                new String[]{
                        "Added cyberanarchy manifest",
                });

        repo.merge("dev-readme", "master");
    }
}
