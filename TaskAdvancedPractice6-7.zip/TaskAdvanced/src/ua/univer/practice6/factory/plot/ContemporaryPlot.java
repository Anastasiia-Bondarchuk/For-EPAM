package ua.univer.practice6.factory.plot;

public class ContemporaryPlot implements PlotFactory{

    String hero, epicCrisis, funnyFriend;
    public ContemporaryPlot(Character hero, EpicCrisis epicCrisis, Character funnyFriend) {
        this.hero=hero.name();
        this.epicCrisis= epicCrisis.name();
        this.funnyFriend=funnyFriend.name();
    }

    @Override
    public String plot() {
        return hero+" feels a bit awkward and uncomfortable. But personal issues fades, when a big trouble comes - "+epicCrisis+". "+hero+" stands up against it, but with no success at first.But putting self together and help of friends, including spectacular funny " +funnyFriend+ " restore the spirit and "+hero+" overcomes the crisis and gains gratitude and respect";
    }
}
