package ua.univer.practice6.factory.plot;

@FunctionalInterface
public interface PlotFactory {
    String plot();
}
