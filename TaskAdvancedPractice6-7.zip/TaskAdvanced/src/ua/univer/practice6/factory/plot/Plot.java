package ua.univer.practice6.factory.plot;

public interface Plot {

}
