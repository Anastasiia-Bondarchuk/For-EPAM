package ua.univer.practice6.factory.plot;

public class ClassicPlot implements PlotFactory{

    String hero, beloved, villain;
    public ClassicPlot(Character hero, Character beloved, Character villain) {
        this.hero= hero.name();
        this.beloved= beloved.name();
        this.villain= villain.name();
    }

    @Override
    public String plot() {

        return hero +  " is great. " + hero +" and "+beloved+" love each other. "
                + villain+" interferes with their happiness but loses in the end.";
    }
}
